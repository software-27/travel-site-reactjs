import React, { useState, useEffect } from 'react';

import { Text, Input, Img, Button, Line, Row, Column } from "components";
import { useNavigate } from "react-router-dom";
import { useLocation} from "react-router-dom";
import Stack from '@mui/material/Stack';

import LinearProgress from '@mui/material/LinearProgress';
import CircularProgress from '@mui/material/CircularProgress';
import './App1.css';

const DIYOverviewPage = () => {
  const items = Array.from({ length: 20 }, (_, index) => index + 1);
  const location = useLocation();
  const receivedData = location.state;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

 

  const [myArray1, setMyArray1] = useState([]);
  const [datam, setDatam] = useState([]);

  var myArray = [];
  useEffect(() => { fetchData(); }, [])

  const fetchData = async () => {
    setLoading(true);
    try {
      const url = receivedData.theme == 0 
      ? `http://desa.celex.com.my/gpt/submit?destination=${receivedData.message}&days=${receivedData.days}&theme=${receivedData.theme}`
      : `http://desa.celex.com.my/gpt/submit?destination=${receivedData.message}&days=${receivedData.days}&theme=${receivedData.theme}`;
    
    const response = await fetch(url);
   // alert(url)
//alert(receivedData.message)
// ${receivedData.message}&days=${receivedData.days}
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }



  
            const data = await response.json();

          //   if (JSON.stringify(data).includes("result")) {
          //  //   alert("yes")
          //   }
          //   else{
          //    // alert("no")
          //   }

let data2= JSON.parse(data.result)
setData(JSON.stringify(data))


//console.log('data:',data2)
var time;
for (const x in data2){
  console.log("aaaa",data2[x])
 // console.log("time",data2[x].afternoon)
 // console.log(x,' : ',data2[x])
  if(x.includes('Day'))
    time = data2[x] 
   // var xx =  parseInt(x++)
   // xx =  x+1
    var aam ='Day '+ (Number(x) + 1)
    // aam = aam.toString()
    console.log("time1"+aam,data2[x][aam].morning)

  myArray.push({
    day: Number(x) + 1,

   morning:data2[x][aam].morning,
   // attraction: data2[x][aam].attraction,
     afternoon:data2[x][aam].afternoon,
    // morning:data2[x][aam].morning,
   evening:data2[x][aam].evening,
    // attraction: data2[x][aam].attraction,
    // afternoon:data2[x][aam].afternoon,
    // morning:data2[x][aam].morning,
    // evening:data2[x][aam].evening,
  });

  //  console.log('time: ',time.attraction);
  //  console.log('time: ',time.afternoon);
  //  console.log('time: ',time.morning);
  //  console.log('time: ',time.evening);

// for (const s in data2){
//   console.log("ppppp",s,' : ',data2[s])
//   myArray.push({
//     day: x,
//     attraction: time[s],
//     afternoon:time[s],
//     morning:time[s],
//     evening:time[s],
//   });
// }
}

     
   
setMyArray1(myArray);
// setData("hh")
console.log("aaaaa2",myArray)

      setError(null);
      setLoading(false);
    
    } catch (error) {
  //    setError(error.message);
      alert(error.message)
      setLoading(false);
    } finally {
      setLoading(false);
    }


    /**start */
    // let data = {
    //     "Destination": "Lahore",
    //     "Day 1": {
    //       "9:00am": "Visit Badshahi Mosque",
    //       "11:00am": "Visit Lahore Fort",
    //       "1:00pm": "Lunch at Food Street",
    //       "3:00pm": "Visit Minar-e-Pakistan",
    //       "5:00pm": "Visit Wazir Khan Mosque",
    //       "7:00pm": "Dinner at a local restaurant"
    //     }
    //   };

      // console.log('data:',data)
      // var time;
      // for (const x in data){
      //   console.log(x,' : ',data[x])
      //   if(x.includes('Day'))
      //     time = data[x] 
      // }
      // console.log('time: ',time);

      // for (const s in time){
      //   console.log(s,' : ',time[s])
      // }
    /**end */
  };


  const navigate = useNavigate();
  
  const [showModal, setShowModal] = React.useState(false);
  const [showModal2, setShowModal2] = React.useState(false);
  const [showModal3, setShowModal3] = React.useState(false);
  const [showModal4, setShowModal4] = React.useState(false);
  const [showModal5, setShowModal5] = React.useState(false);
  const [showModal6, setShowModal6] = React.useState(false);

  return (
    <>
     {/* {loading ? <CircularProgress /> : */}
      <div className="bg-[#EAEBEF] flex flex-col font-ptsans items-center justify-start mx-[auto] w-[100%]">
      
    
        <div className="bg-gray_51 flex flex-row items-center justify-start p-[15px] xl:p-[15px] shadow-bs5 xl:w-[100%] w-[100%]">
          <div className="justify-between xl:w-screen w-screen flex md:flex-col sm:flex-col xl:flex-col flex-row md:gap-[20px] xl:gap-[20px] sm:gap-[20px] items-center justify-start md:px-[20px] sm:px-[20px] xl:px-[20px]">
            <Row><Img
              src="images/img_halalholidaylogo.png"
              className="xl:h-[65%] h-[65px] sm:h-[auto] object-cover md:w-[100%] xl:w-[24%] sm:w-[100%] w-[24%] cursor-pointer"
              alt="HalalHolidayLogo"
              onClick={() => navigate("/")}
            />
            <div className="w-[40%] xl:w-[100%] grid grid-row-2 grid-flow-col justify-end">
              <Text
                className="md:ml-[0] sm:ml-[0] ml-[30px] xl:ml-[30px] mt-6 not-italic text-black_900 text-left w-[auto]"
                variant="body4"
              >
                MYR
              </Text>
              <div className="grid grid-row-2 grid-flow-col mt-6 xl:mt-6">
                <Img
                  src="images/coins.svg"
                  className="common-pointer h-[20px] sm:h-[auto] xl:h-[20px] xl:ml-[10px] md:ml-[0] sm:ml-[0] ml-[10px] object-cover xl:w-[20px] md:w-[100%] sm:w-[100%] w-[20px]"
                  alt="coins"
                  onClick={() => setShowModal(true)}

                />

                  {showModal ? (
                        <>
                          <div
                            className="overflow-auto justify-center items-center mx-[400px] my-[150px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >


                            {/*Body*/}

                            <div className="bg-white w-[100%]">

                              <div className="mt-2 p-2 grid place-items-center w-[100%] ">
                              
                                <text className="mt-2 font-bold text-[20px]">
                                  Trip budget
                                </text>

                                <Line className="h-[2px] w-full bg-gray_300 my-4"/>
                                
                                <div className="grid grid-row-2 grid-flow-col text-[13px]">
                                  <Img
                                    src="images/plane.svg"
                                    className="mr-1 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                    alt="plane"

                                  />
                                  <text classname="">
                                    TRANSPORTATION
                                  </text>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Kuala Lumpur To Tokyo
                                      </text>
                                      <text className="text-[13px]">
                                        No. of people
                                      </text>
                                    </div>

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="text-[13px]">
                                        Dep: 27 Mar 2023 00:00 Arr: 27 Mar 2023 09:20
                                      </text>
                                      <text className="text-[13px] ml-[60px]">
                                        -
                                      </text>
                                      <text className="text-right text-[13px] text-[#1A8FF8]">
                                        Enter total price
                                      </text>
                                    </div>

                                  </div>

                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Tokyo To Kuala Lumpur
                                      </text>
                                      <text className="text-[13px]">
                                        No. of people
                                      </text>
                                    </div>

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="text-[13px]">
                                        Dep: 30 Mar 2023 11:00 Arr: 30 Mar 2023 20:20
                                      </text>
                                      <text className="text-[13px] ml-[60px]">
                                        -
                                      </text>
                                      <text className="text-right text-[13px] text-[#1A8FF8]">
                                        Enter total price
                                      </text>
                                    </div>

                                  </div>
                                </div>

                                <div className="mt-2 grid grid-row-2 grid-flow-col text-[13px]">
                                  <Img
                                    src="images/house.svg"
                                    className="mr-1 mt-[2px] common-pointer h-[15px] sm:h-[auto] xl:h-[15px] md:ml-[0] sm:ml-[0] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[15px] w-[15px]"
                                    alt="house"

                                  />
                                  <text classname="">
                                    ACCOMODATION
                                  </text>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Time Sharing Stay 池袋
                                      </text>
                                      <text className="text-[13px]">
                                        No. of people
                                      </text>
                                    </div>

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="text-[13px]">
                                        27 Mar 2023 - 30 Mar 2023
                                      </text>
                                      <text className="text-[13px] ml-[160px] font-bold">
                                        3 persons
                                      </text>
                                      <text className="text-right text-[15px] text-[#1A8FF8] font-bold">
                                        RM1687.21
                                      </text>
                                    </div>

                                    <text className="mt-2 text-[13px] text-[#1A8FF8] font-bold">
                                      Book Hotel
                                    </text>

                                  </div>
                                </div>

                                <div className="mt-2 grid grid-row-2 grid-flow-col text-[13px]">
                                  <Img
                                    src="images/coins.svg"
                                    className="mr-1 mt-[2px] common-pointer h-[15px] sm:h-[auto] xl:h-[15px] md:ml-[0] sm:ml-[0] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[15px] w-[15px]"
                                    alt="coins"

                                  />
                                  <text classname="">
                                    OTHER EXPENSES
                                  </text>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        City Transportation
                                      </text>
                                      <text className="text-[13px] ml-[40px]">
                                        No. of people
                                      </text>
                                    </div>

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="text-[13px]">
                                        Transportation cost within the city
                                      </text>
                                      <text className="text-[13px] ml-[150px] font-bold">
                                        -
                                      </text>
                                      <text className="text-right text-[13px] text-[#1A8FF8] font-bold">
                                        Enter Total Price
                                      </text>
                                    </div>

                                  </div>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Food & Drinks
                                      </text>
                                      <text className="text-[13px] ml-[70px]">
                                        No. of people
                                      </text>
                                    </div>

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="text-[13px]">
                                        Food cost for your trip
                                      </text>
                                      <text className="text-[13px] ml-[220px] font-bold">
                                        -
                                      </text>
                                      <text className="text-right text-[13px] text-[#1A8FF8] font-bold">
                                        Enter Total Price
                                      </text>
                                    </div>

                                  </div>
                                </div>

                                <div className="common-pointer mt-2 w-full">
                                  <text className="text-left text-[14px] text-[#1A8FF8]">
                                    Add expenses
                                  </text>
                                </div>

                                <div className="mt-2 border-dotted border-t w-full h-2">
                                </div>

                              </div>

                              <div className="grid grid-row-2 grid-flow-col px-4">
                                <text className="font-bold">
                                  TOTAL
                                </text>
                                <text className="text-[#E47777] font-bold text-right">
                                  RM1687.21
                                </text>
                              </div>


                              <div className="mt-2 p-3">

                                <div>
                                  <button
                                    className="w-full rounded text-white bg-[#4AB879] hover:bg-[#42CC7D] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                    type="button"
                                    onClick={() => setShowModal(false)}
                                  >
                                    OK
                                  </button>
                                </div>

                              </div>
                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}
                
                <Img
                  src="images/printer.svg"
                  className="common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                  alt="printer"
                />
                
                <Img
                  src="images/share.svg"
                  className="common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                  alt="share"
                  onClick={() => setShowModal2(true)}

                />

                {showModal2 ? (
                        <>
                          <div
                            className="overflow-auto justify-center items-center mx-[400px] my-[100px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >
                            


                            {/*Body*/}

                            <div className="bg-white w-[100%]">

                              <div className="mt-2 p-2 grid place-items-center w-[100%] ">

                                
                                <div className="bg-white w-full ">

                                  <Img
                                        src="images/close.svg"
                                        className="items-left w-full mr-1 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] ml-[10px] xl:ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                        alt="close"
                                        onClick={() => setShowModal2(false)}

                                      />

                                </div>
                                <div className="border-4 border-[#FFD7A4] rounded-full bg-[#FFB049] p-7">
                                  <Img
                                      src="images/sharew.svg"
                                      className=" common-pointer h-[40px] sm:h-[auto] xl:h-[40px] object-cover md:w-[100%] sm:w-[100%] xl:w-[40px] w-[40px]"
                                      alt="sharew"

                                    />
                                </div>
                              
                                <text className="mt-4 font-bold text-[23px]">
                                  SHARE YOUR PLAN
                                </text>

                                <div>
                                  <text className="mt-4 font-bold text-[18px]">
                                    Let your friends & family take a look
                                  </text>
                                </div>

                                <div className="mt-2 p-3 grid grid-row-2 grid-flow-col w-[50%]">

                                  <div>
                                    <button
                                      className="grid grid-row-2 grid-flow-col w-full rounded text-white bg-[#4A69A0] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                      type="button"
                                    >
                                      <Img
                                      src="images/facebookw.svg"
                                      className="mr-2 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                      alt="faebookw"

                                    />
                                      facebook
                                    </button>
                                  </div>

                                  <div className="ml-2">
                                    <button
                                      className="grid grid-row-2 grid-flow-col w-full rounded text-white bg-[#45B0E4] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                      type="button"
                                    >
                                      <Img
                                      src="images/twitter.svg"
                                      className="mr-2 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                      alt="twitter"

                                    />
                                      twitter
                                    </button>
                                  </div>

                                </div>

                                <div className="bg-[#F7F7F7] place-items-center grid grid-row-2 grid-flow-col w-full p-4">

                                  <div className="w-[80%]">
                                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email</label>
                                    <input type="email" id="email" class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required/>
                                  </div>

                                  <div className="w-[30%] mt-[33px]">
                                    <button
                                      className="grid grid-row-2 grid-flow-col w-full rounded text-white bg-[#4AB879] hover:bg-[#42CC7D] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                      type="button"
                                    >
                                      Send
                                    </button>
                                  </div>

                                </div>

                              </div>

                              <div className="place-items-center  grid grid-row-2 grid-flow-col px-4 pb-5">
                                <text className=" text-[13px]">
                                  You can also find this trip plan under your profile
                                </text>
                              </div>

                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}
                
                <Img
                  src="images/settings.svg"
                  className="common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                  alt="settings"
                  onClick={() => setShowModal3(true)}

                />

                  {showModal3 ? (
                        <>
                          <div
                            className="overflow-auto justify-center items-center mx-[400px] my-[200px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >
                            


                            {/*Body*/}

                            <div className="bg-white w-[100%]">

                              <div className="mt-2 p-2 grid place-items-center w-[100%] ">

                                
                                <div className="bg-white w-full ">

                                  <Img
                                        src="images/close.svg"
                                        className="items-left w-full mr-1 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] ml-[10px] xl:ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                        alt="close"
                                        onClick={() => setShowModal3(false)}

                                      />

                                </div>
                              
                                <text className="mt-4 font-bold text-[23px]">
                                  Settings
                                </text>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Time Format
                                      </text>
                                      <div className="grid grid-row-2 grid-flow-col">
                                      
                                        <div class="flex items-center">
                                            <input checked id="default-radio-1" type="radio" value="" name="default-radio" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-1" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">24 Hours</label>
                                        </div>
                                        <div class="flex items-center">
                                            <input id="default-radio-2" type="radio" value="" name="default-radio" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-2" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">12 Hours</label>
                                        </div>

                                      </div>
                                    </div>

                                  </div>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Distance
                                      </text>
                                      <div className="grid grid-row-2 grid-flow-col">
                                      
                                        <div class="flex items-center ">
                                            <input checked id="default-radio-1" type="radio" value="" name="default-radio3" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-1" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Kilometer</label>
                                        </div>
                                        <div class="flex items-center">
                                            <input id="default-radio-2" type="radio" value="" name="default-radio3" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-2" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Miles</label>
                                        </div>

                                      </div>
                                    </div>

                                  </div>
                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <div className="grid grid-row-2 grid-flow-col">
                                      <text className="font-bold">
                                        Plan Mode
                                      </text>
                                      <div className="grid grid-row-2 grid-flow-col">
                                      
                                        <div class="flex items-center">
                                            <input id="default-radio-1" type="radio" value="" name="default-radio2" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-1" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Public</label>
                                        </div>
                                        <div class="flex items-center">
                                            <input checked id="default-radio-2" type="radio" value="" name="default-radio2" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label for="default-radio-2" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Private</label>
                                        </div>

                                      </div>
                                    </div>

                                  </div>
                                </div>

                                <div className="mt-2 p-3 grid grid-row-2 grid-flow-col w-full">

                                  <div>
                                    <button
                                      className="grid grid-row-2 grid-flow-col w-full rounded text-white bg-[#4AB879] hover:bg-[#42CC7D] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                      type="button"
                                      onClick={() => setShowModal3(false)}

                                    >
                                      Apply Settings
                                    </button>
                                  </div>

                                </div>

                              </div>

                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}
                
                <Img
                  src="images/info.svg"
                  className="common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                  alt="info"
                  onClick={() => setShowModal4(true)}

                />

                  {showModal4 ? (
                        <>
                          <div
                            className="overflow-auto justify-center items-center mx-[400px] my-[100px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >
                            


                            {/*Body*/}

                            <div className="bg-white w-[100%]">

                              <div className="mt-2 p-2 grid w-[100%] ">

                                
                                <div className="bg-white w-full ">

                                  <Img
                                    src="images/close.svg"
                                    className="items-left w-full mr-1 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] ml-[10px] xl:ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                    alt="close"
                                    onClick={() => setShowModal4(false)}

                                  />

                                </div>
                              
                                <text className="mt-4 font-bold text-[23px]">
                                  Trip Plan Overview
                                </text>

                                <Line className="bg-gray_200 h-[1px] w-full my-3"/>

                                <div className="w-[35%] grid grid-row-1 grid-flow-col place-items-left">
                                  <Img
                                    src="images/arrowr.svg"
                                    className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                    alt="arrowr"

                                  />
                                  <text className="text-[13px]">
                                    This is an overview of your trip plan.
                                  </text>

                                </div>

                                <div className="w-[63%] grid grid-row-1 grid-flow-col place-items-left">
                                  <Img
                                    src="images/arrowr.svg"
                                    className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                    alt="arrowr"

                                  />
                                  <text className="text-[13px]">
                                    In order to edit this plan, you need to Click on the "EDITABLE VIEW" tab.
                                  </text>

                                </div>

                                <div className="w-[100%]">
                                  <div className="mt-2 bg-[#F4F4F4] p-4 w-full">

                                    <text className="font-bold text-[15px] mb-2">
                                      Understanding the Trip Overview
                                    </text>

                                    <div className="mt-2 w-[100%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                      The first time you land on this page, you will see a suggested trip plan based on the elements you have selected in the previous steps.
                                      </text>

                                    </div>

                                    <div className="w-[81.5%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        The suggestion would vary based on whether you have added something to your bindle or not.
                                      </text>

                                    </div>

                                    <div className="w-[100%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        Thereafter whenever you land on this page, you will see the most recent version of your plan (This version is already saved to your profile)
                                      </text>

                                    </div>

                                    <div className="w-[82%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        The itinerary is displayed day wise which can be navigated by clicking the left and right arrows.
                                      </text>

                                    </div>

                                    <div className="w-[100%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        Any blocks(accommodation block, transportation block, activity block, etc.), if in conflict (i.e. two or more blocks are at the same time or an incorrect travel times, etc.) can be seen in red.
                                      </text>

                                    </div>

                                    <div className="w-[73.5%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        Your Bindle (at the bottom of the screen) contains the activities you have added to it.
                                      </text>

                                    </div>

                                    <div className="w-[81%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        Your Bindle also shows the activities that are added to the plan and the activities that are not.
                                      </text>

                                    </div>

                                    <div className="w-[57.5%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        You can View/Edit your notes for each of your days from this step.
                                      </text>

                                    </div>

                                    <div className="w-[47%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        Clicking on the trip title will enable you to change it.
                                      </text>

                                    </div>

                                    <div className="w-[90%] grid grid-row-1 grid-flow-col place-items-left">
                                      <Img
                                        src="images/arrowr.svg"
                                        className="mt-1 items-left w-full mr-1 common-pointer h-[10px] sm:h-[auto] md:ml-[0] sm:ml-[0] ml-[10px] object-fit md:w-[100%] sm:w-[100%] w-[7px]"
                                        alt="arrowr"

                                      />
                                      <text className="text-[13px]">
                                        You can take a print of your plan or share it with others by clicking on the respective icons at the header.
                                      </text>

                                    </div>

                                  </div>
                                </div>

                                

                                <div className="mt-2 p-3 grid grid-row-2 grid-flow-col w-full">

                                  <div>
                                  </div>

                                </div>

                              </div>

                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}

              </div>
              <Button
                className="md:ml-[0] sm:ml-[3] ml-[30px] xl:ml-[10px] not-italic hover:underline text-blue_A400 text-left xl:w-[100%] w-[50%]"
                variant="body4"
                onClick={() => navigate("/signin")}

              >
                Sign In
              </Button>
              <Button
                className="cursor-pointer font-normal leading-[normal] min-w-[134px] md:ml-[0] sm:ml-[0] ml-[34px] md:mt-[0] sm:mt-[0] my-[11px] not-italic text-[17px] hover:bg-blue_A400 hover:text-white text-blue_A400 text-center xl:w-[10px] w-[10%]"
                shape="RoundedBorder5"
                size="md"
                variant="OutlineBlueA400"
                onClick={() => navigate("/signup")}

              >
                Create Account
              </Button>
            </div>
            </Row>
          </div>
        </div>
        <div className="justify-between flex bg-white shadow-lg p-4 w-full">
          <Row className="grid grid-row-2 grid-flow-col">
            <text className="ml-2 text-[20px]">
              {receivedData.days} days trip to {receivedData.message}
            </text>
            <Img
              src="images/edit.svg"
              className="common-pointer h-[25px] sm:h-[auto] xl:h-[25px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[25px] w-[25px]"
              alt="edit"
            />
          </Row>
          <div className="grid grid-row-2 grid-flow-col w-[24%] xl:w-[26%]">
            <div className="border border-black rounded-full items-center flex xl:p-2 p-2 xl:h-14 xl:w-14 xl:mr-2 mr-2">
              <Img
                src="images/bulb.svg"
                className="justify-center ml-1 h-[20px] sm:h-[auto] xl:h-[20px] xl:ml-1 md:ml-[0] sm:ml-[0] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px] items-center"
                alt="bulb"
                onClick={() => setShowModal6(true)}

              />
            </div>

            {showModal6 ? (
                        <>
                          <div
                            className="justify-center items-center mx-[400px] my-[100px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >
                            


                            {/*Body*/}

                            <div className="bg-[#FFFAC1] w-[100%]">

                              <div className="mt-2 p-2 grid w-[100%] ">

                                
                                <div className="w-full ">

                                  <Img
                                    src="images/close.svg"
                                    className="items-left w-full mr-1 common-pointer h-[20px] sm:h-[auto] xl:h-[20px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[20px] w-[20px]"
                                    alt="close"
                                    onClick={() => setShowModal6(false)}

                                  />

                                </div>
                              
                                <div className="mt-4">
                                  <text className="mt-4 font-bold text-[#5A5111] text-[23px]">
                                    Disclaimer
                                  </text>
                                </div>

                                <div className="mt-1">
                                  <text className=" text-[#5A5111] text-[14px]">
                                  This is an algorithmically generated itinerary. Though we try to be as accurate as possible based on data available with us, user discretion is advised.
                                  </text>
                                </div>

                                <div className="mt-1">
                                  <text className=" text-[#5A5111] text-[14px]">
                                    Please take the following into consideration while going through your itinerary:
                                  </text>
                                </div>

                                <div className="mt-1 list-disc list-outside text-[#5A5111] text-[14px]">
                                  <li>Pricing information may vary at the time of your booking. You can book flights, hotels, tours, transfers, tickets individually</li>
                                  <li>You can modify any element in the itinerary. This might have an impact on other elements of the itinerary</li>
                                  <li>If you have difficulty in planning your own trip, please connect with our travel agents who can help you plan the full trip</li>
                                  <li>Suggested accommodations are 3-5 star hotels, nearest to city-center, and available on the chosen dates</li>
                                  <li>Time slot of tours is chosen according to the collected data & possibly change at the time of booking due to unavailability</li>
                                  <li>Distance between two 'Points Of Interest' (POI) and the time taken to travel are estimated based on the geographical data available with us, on ground conditions may be different</li>
                                  <li>Tours are categorized based on the data provided by third-party vendors</li>
                                  <li>POIs might get repeated through some tours, as some may be seen only as you pass along, user discretion is advised</li>
                                  <li>The hotel pickup transport duration is assumed to be 1 hour by the planner; provision to change it is available</li>
                                </div>


                                

                                <div className="mt-2 p-3 grid grid-row-2 grid-flow-col w-full">

                                  <div>
                                  </div>

                                </div>

                              </div>

                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}

            <Button className="border-none bg-[#067DE8] hover:bg-[#1A8FF8] text-white p-3 mr-2"
              onClick={() => setShowModal5(true)}>
              
              Talk to a Travel Agent
            </Button>

            {showModal5 ? (
                        <>
                          <div
                            className="justify-center items-center mx-[400px] my-[150px] flex-nowrap fixed inset-0 z-50 outline-none focus:outline-none"
                          >


                            {/*Body*/}

                            <div className="bg-white w-[100%]">

                              <div className="mt-2 p-2 grid place-items-center w-[100%] ">
                                <text className="pt-1 text-[14px] ">
                                  Want to book your trip?
                                </text>
                              
                                <text className="mt-2 font-bold text-[20px]">
                                  Get a Free Quotation!
                                </text>

                                <text className="pt-1 text-[14px] text-center w-[95%]">
                                  Talk to our expert travel agent for your travel needs. Our expert will connect with you over email, phone or WhatsApp to help you with your trip planning and booking
                                </text>

                                <div>

                                  <div className="mt-4 grid grid-row-2 grid-flow-col" >
                                    <div>
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Name
                                        <text className="ml-1 text-gray_400 text-[12px] ">
                                          (Mandatory)
                                        </text>
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="text" placeholder="Enter Name"/>
                                    </div>

                                    <div className="ml-5">
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Mobile Number
                                        <text className="ml-1 text-gray_400 text-[12px] ">
                                          (Mandatory)
                                        </text>
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="number" placeholder="Enter Mobile Number"/>
                                      <div class="flex items-center mt-2">
                                          <input id="default-checkbox" type="checkbox" value="" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                          <label for="default-checkbox" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Contact me on WhatsApp</label>
                                      </div>
                                    </div>
                                  </div>

                                </div>

                                <div>

                                  <div className="xl:ml-14 mt-4 xl:mt-4 grid grid-row-2 grid-flow-col" >
                                    <div>
                                      <label class="block text-gray-700 text-sm xl:mb-1 mb-1" for="username">
                                        Call me on
                                        <text className="ml-1 text-gray_400 text-[12px] ">
                                          (Mandatory)
                                        </text>
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="number" placeholder="Enter Call me on Date"/>
                                    </div>

                                    <div className="ml-5">
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Time
                                        <text className="ml-1 text-gray_400 text-[12px] ">
                                          (Mandatory)
                                        </text>
                                      </label>
                                      <select id="countries" class="border border-gray_400 rounded w-[200px] py-2 px-3 text-gray-700">
                                        <option selected>Select Time</option>
                                        <option value="1">00:00 - 02:00</option>
                                        <option value="2">02:00 - 04:00</option>
                                        <option value="3">04:00 - 06:00</option>
                                        <option value="4">06:00 - 08:00</option>
                                        <option value="5">08:00 - 10:00</option>
                                      </select>
                                    </div>
                                  </div>

                                </div>

                                <div>

                                  <div className="mt-4 grid grid-row-2 grid-flow-col" >
                                    <div>
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Email
                                        <text className="ml-1 text-gray_400 text-[12px] ">
                                          (Mandatory)
                                        </text>
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="email" placeholder="Enter Email ID"/>
                                    </div>

                                    <div className="ml-5">
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        From City
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="text" placeholder="Enter From City"/>
                                    </div>
                                  </div>

                                </div>

                                <div>

                                  <div className="mt-4 grid grid-row-2 grid-flow-col" >
                                    <div>
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Destination
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700 placeholder:font-bold" id="name" type="text" placeholder="Tokyo"/>
                                    </div>

                                    <div className="ml-5">
                                      <label class="block text-gray-700 text-sm mb-1" for="username">
                                        Departure Date
                                      </label>
                                      <input class="border border-gray_400 rounded w-full py-2 px-3 text-gray-700" id="name" type="number" placeholder="Enter Departure Date"/>
                                    </div>
                                  </div>
                                </div>


                              </div>


                              <div className="mt-2 p-3">

                                <div>
                                  <button
                                    className="w-full rounded text-white bg-[#4AB879] hover:bg-[#42CC7D] font-bold  px-6 py-3 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                    type="button"
                                    onClick={() => setShowModal5(false)}
                                  >
                                    Submit Form
                                  </button>
                                </div>

                                <div className="mt-2 grid place-items-center grid-row-2 grid-flow-col">
                                  <text className="text-center text-[13px] ">
                                    By submitting this form, you authorize TripHobo to contact you for this inquiry.
                                  </text>
                                </div>
                                <div className="grid place-items-center grid-row-2 grid-flow-col">
                                  <text className="text-center text-[13px] ">
                                    Your information will be kept confidential.
                                  </text>
                                </div>

                              </div>
                            </div>

                          </div>

                          <div className="opacity-30 fixed inset-0 z-40 bg-black"></div>

                        </>
                      ) : null}

            <Button className="border-none bg-[#4AB879] hover:bg-[#42CC7D] text-white p-3"
              onClick={() => navigate("/ota2")} 
              >
              Edit This Plan
            </Button>
          </div>
        </div>
        <div className="place-items-center grid bg-white shadow-inner p-4 w-full">
        <div>
                      <text className="common-pointer font-bold border-b border-b-2 border-b-[#6392F9] text-[#6392F9] p-3"

   onClick={() => {
              
              const dataToPass = { message: receivedData.message,days:receivedData.message,theme:receivedData.theme };
              navigate('/ota1', { state: dataToPass })}}>
              OVERVIEW
            </text>
            <text className="common-pointer ml-10 hover:border-b hover:border-b-2 hover:border-b-[#6392F9] hover:text-[#6392F9] p-3" 

            onClick={() => {
              
              const dataToPass = { message: receivedData.message,days:receivedData.message,theme:receivedData.theme };
              navigate('/ota2', { state: dataToPass })}}>
              EDITABLE VIEW
            </text>
          </div>
        </div>
        <div className="md:h-[3200px] sm:h-[3500px] h-[796px] mt-[4px] relative w-[100%]">
          {/* <div className="absolute h-[600px] md:h-[3196px] sm:h-[3196px] inset-x-[0] mx-[auto] top-[0] w-[100%]">
            
            <div className="grid place-items-center grid-row-2 grid-flow-col w-full mt-10"> */}

             

            
            <div className="App">
            {!loading ? (
        <div className="scrollable-list">
          {myArray1.map((item) => (
            <div key={item} className="list-item">
             <div className="grid place-items-center xl:mb-[10px]">
                <div className="bg-white p-3 rounded-lg grid grid-row-2 grid-flow-col w-[280px]">
                  <div className="">
                    <text className="font-bold">
                  Day {item.day}
                    </text>
                  
                  </div>
                 
                </div>

                <div className="mt-5 bg-white p-3 border border-l border-l-[#BEBEBE] border-l-[3px] rounded-lg w-[280px] flex items-center">
  <Img
    src="images/route.png"
    className="rounded-lg h-[90px] sm:h-[auto] xl:h-[90px] md:ml-[0] sm:ml-[0] object-fit md:w-[100%] sm:w-[100%] xl:w-[90px] w-[90px]"
    alt="route"
  />
  <div className="ml-2">
    <div>
      <text className="text-[14px] font-bold">
        Activity:{item.morning.activity}
        Breakfast:{item.morning.breakfast}
        Restaurant:{item.morning.restaurant}
      </text>
    </div>
  </div>
</div>

<div className="mt-2 bg-white p-3 rounded-lg border-l border-l-[#AD735A] border-l-[3px] w-[280px] flex items-center">
  <Img
    src="images/hotel_5.png"
    className="rounded-lg h-[90px] xl:h-[90px] sm:h-[auto] md:ml-[0] sm:ml-[0] object-cover md:w-[100%] sm:w-[100%] xl:w-[90px] w-[90px]"
    alt="hotel"
  />
  <div className="ml-2">
    <div>
      <text className="text-[14px] font-bold">
        Activity:{item.afternoon.activity}
        Lunch:{item.afternoon.lunch}
        Restaurant:{item.afternoon.restaurant}
      </text>
    </div>
  </div>
</div>

<div className="mt-2 bg-white p-3 rounded-lg border-l border-l-[#10A563] border-l-[3px] w-[280px] flex items-center">
  <Img
    src="images/park.png"
    className="rounded-lg h-[90px] xl:h-[90px] sm:h-[auto] md:ml-[0] sm:ml-[0] object-cover md:w-[100%] sm:w-[100%] xl:w-[90px] w-[90px]"
    alt="park"
  />
  <div className="mr-[40px]">
    <div>
      <text className="text-[14px] font-bold">
        Activity:{item.evening.activity}
        Breakfast:{item.evening.dinner}
        Restaurant:{item.evening.restaurant}
      </text>
    </div>
  </div>
</div>

                
          
                
              </div>
          
            </div>
          ))}
     
  
              
              
            </div>
            
            ) : (
              // render loading message while waiting for data
              <div>Loading... 
                
             
                
    <CircularProgress size={12} sx={{ color: 'black' }} /></div>
            )}

          </div>
        </div>
          
      </div>
{/* } */}
    </>
  );
};

export default DIYOverviewPage;
