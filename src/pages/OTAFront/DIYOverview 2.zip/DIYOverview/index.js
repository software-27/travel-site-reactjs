import React, { useState, useEffect } from 'react';

import { Text, Input, Img, Button, Line, Row, Column } from "components";
import { useNavigate } from "react-router-dom";
import { useLocation} from "react-router-dom";
import Stack from '@mui/material/Stack';

import LinearProgress from '@mui/material/LinearProgress';
import CircularProgress from '@mui/material/CircularProgress';
import './App1.css';
import { IoPartlySunnyOutline } from 'react-icons/io5';
import { BiMoon } from 'react-icons/bi';

import { GiKnifeFork } from 'react-icons/gi';

import { BsSun } from 'react-icons/bs';
const DIYOverviewPage = () => {
  const items = Array.from({ length: 20 }, (_, index) => index + 1);
  const location = useLocation();
  const receivedData = location.state;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

 

  const [myArray1, setMyArray1] = useState([]);
  const [datam, setDatam] = useState([]);

  var myArray = [];
  useEffect(() => { fetchData(); }, [])

  const fetchData = async () => {
    setLoading(true);
    try {
      const url = receivedData.theme == 0 
      ? `http://desa.celex.com.my/gpt/submit?destination=${receivedData.message}&days=${receivedData.days}&theme=${receivedData.theme}`
      : `http://desa.celex.com.my/gpt/submit?destination=${receivedData.message}&days=${receivedData.days}&theme=${receivedData.theme}`;
    
    const response = await fetch(url);
   // alert(url)
//alert(receivedData.message)
// ${receivedData.message}&days=${receivedData.days}
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }



  
            const data = await response.json();

       

let data2= JSON.parse(data.result)
setData(JSON.stringify(data))


//console.log('data:',data2)
var time;
for (const x in data2){
  console.log("aaaa",data2[x])
 // console.log("time",data2[x].afternoon)
 // console.log(x,' : ',data2[x])
  if(x.includes('Day'))
    time = data2[x] 
   // var xx =  parseInt(x++)
   // xx =  x+1
    var aam ='Day '+ (Number(x) + 1)
    // aam = aam.toString()
    console.log("time1"+aam,data2[x][aam].morning)

  myArray.push({
    day: Number(x) + 1,

   morning:data2[x][aam].morning,
   // attraction: data2[x][aam].attraction,
     afternoon:data2[x][aam].afternoon,
    // morning:data2[x][aam].morning,
   evening:data2[x][aam].evening,
    // attraction: data2[x][aam].attraction,
    // afternoon:data2[x][aam].afternoon,
    // morning:data2[x][aam].morning,
    // evening:data2[x][aam].evening,
  });


}

     
   
setMyArray1(myArray);
// setData("hh")
console.log("aaaaa2",myArray)

      setError(null);
      setLoading(false);
    
    } catch (error) {
  //    setError(error.message);
      alert(error.message)
      setLoading(false);
    } finally {
      setLoading(false);
    }


  
  };


  const navigate = useNavigate();
  
  const [showModal, setShowModal] = React.useState(false);
  const [showModal2, setShowModal2] = React.useState(false);
  const [showModal3, setShowModal3] = React.useState(false);
  const [showModal4, setShowModal4] = React.useState(false);
  const [showModal5, setShowModal5] = React.useState(false);
  const [showModal6, setShowModal6] = React.useState(false);

  return (
    <>
  
      <div className="bg-[#EAEBEF] flex flex-col font-ptsans items-center justify-start mx-[auto] w-[100%]">
      
    
      <div className="bg-gray_51 flex flex-row items-center justify-start p-4 md:p-5 xl:p-6 shadow-bs5 w-full">
  <div className="flex flex-col md:flex-row gap-4 md:gap-5 xl:gap-6 items-center justify-start px-4 md:px-5 xl:px-6 w-full">
    <Img
      src="images/img_halalholidaylogo.png"
      className="h-auto w-32 md:w-40 xl:w-48 object-contain cursor-pointer"
      alt="HalalHolidayLogo"
      onClick={() => navigate("/")}
    />
  </div>
</div>



<div className="justify-between flex bg-white shadow-lg p-4 w-full">
  <Row className="grid grid-row-2 grid-flow-col">
    <text className="ml-2 text-[20px] sm:text-[18px] md:text-[20px] xl:text-[20px]">
      {receivedData.days} days trip to {receivedData.message}
    </text>
    <Img
      src="images/edit.svg"
      className="common-pointer h-[25px] sm:h-[20px] md:h-[25px] xl:h-[25px] md:ml-[0] sm:ml-[0] xl:ml-[10px] ml-[10px] object-cover md:w-[100%] sm:w-[100%] xl:w-[25px] w-[25px]"
      alt="edit"
    />
  </Row>
</div>

<div className="place-items-center grid bg-white shadow-inner p-4 w-full">
  <div>
    <text
      className="common-pointer font-bold border-b border-b-2 border-b-[#6392F9] text-[#6392F9] p-3"
      onClick={() => {
        const dataToPass = {
          message: receivedData.message,
          days: receivedData.message,
          theme: receivedData.theme
        };
        navigate('/ota1', { state: dataToPass });
      }}
    >
      OVERVIEW
    </text>
    <text
      className="common-pointer ml-10 sm:ml-4 md:ml-6 lg:ml-10 hover:border-b hover:border-b-2 hover:border-b-[#6392F9] hover:text-[#6392F9] p-3"
      onClick={() => {
        const dataToPass = {
          message: receivedData.message,
          days: receivedData.message,
          theme: receivedData.theme
        };
        navigate('/ota2', { state: dataToPass });
      }}
    >
      EDITABLE VIEW
    </text>
  </div>
</div>

<div>
  <div className="App ">
    {!loading ? (
      <div className="scrollable-list">
        {myArray1.map((item) => (
          <div key={item} className="list-item list-item-responsive">
            <div className="grid place-items-center xl:mb-[10px]">
              <div className="bg-white p-3 rounded-lg grid grid-row-2 grid-flow-col w-full md:w-[280px]">
                <div className="">
                  <text className="font-bold">
                    Day {item.day}
                  </text>
                </div>
              </div>
            

              <div className="mt-5 bg-white p-3 border border-l border-l-[#6aa677] border-l-[3px] rounded-lg w-full md:w-[280px] flex flex-col items-start">
  <div className="flex items-center mb-2">
    <BsSun
      size={18}
      className="rounded-lg w-4 h-4" // Set fixed width and height
      alt="route"
    />
    <text className="text-[14px] font-bold ml-2">
      Activity
    </text>
  </div>
  <div className="ml-2">
    <div>
      <text className="text-[10px] ">
      <span style={{ fontSize: '12px',fontWeight: 'normal' }}> {item.morning.activity}</span>

<br />
<span style={{ fontSize: '10px',fontWeight: 'normal' }}> {item.morning.breakfast}</span>


      </text>
    </div>
  </div>
</div>




<div className="mt-5 p-3 rounded-lg grid grid-row-2 grid-flow-col w-full md:w-[280px] h-[20px] flex items-center" style={{ backgroundColor: 'rgba(130, 130, 130, 0.2)' }}>
  <div className="mt-[-10px]">
    <div className="flex items-center mb-2">
     <GiKnifeFork
       size={18}
       className="rounded-lg w-3 h-3"
        alt="route"
        style={{ color: '#45B9B4' }}
      />
      <text className="text-sm ml-5" style={{ color: '#45B9B4', fontSize: '10px', marginLeft: '20px' }}>
      <span style={{ fontSize: '10px',fontWeight: 'bold' }}>Lunch -- </span>
      <span style={{ fontSize: '8px',fontWeight: 'normal' }}>nasi kadar {item.day}</span>
      </text>
    </div>
  </div>
</div>





<div className="mt-5 bg-white p-3 border border-l border-l-[#00A19A] border-l-[3px] rounded-lg w-full md:w-[280px] flex flex-col items-start">
  <div className="flex items-center mb-2">
  <IoPartlySunnyOutline
   size={18}
   className="rounded-lg w-4 h-4"
      alt="route"
    
    />
    <text className="text-[14px] font-bold ml-2">
      Activity
    </text>
  </div>
  <div className="ml-2">
    <div>
      <text className="text-[10px] ">
      
        <span style={{ fontSize: '12px',fontWeight: 'normal' }}> {item.morning.activity}</span>

        <br />
        <span style={{ fontSize: '10px',fontWeight: 'normal' }}> {item.morning.breakfast}</span>

      
      </text>
    </div>
  </div>
</div>
<div className="mt-5 p-3 rounded-lg grid grid-row-2 grid-flow-col w-full md:w-[280px] h-[20px] flex items-center" style={{ backgroundColor: 'rgba(130, 130, 130, 0.2)' }}>
  <div className="mt-[-10px]">
    <div className="flex items-center mb-2">
    <GiKnifeFork
     size={18}
     className="rounded-lg w-3 h-3"
     style={{ color: '#45B9B4' }}
        alt="route"
      />
      <text className="text-sm ml-5" style={{ color: '#45B9B4', fontSize: '10px', marginLeft: '20px' }}>
      <span style={{ fontSize: '10px',fontWeight: 'bold' }}>Dinner -- </span>
      <span style={{ fontSize: '8px',fontWeight: 'normal' }}>nasi kadar {item.day}</span>
      </text>
    </div>
  </div>
</div>


<div className="mt-5 bg-white p-3 border border-l border-l-[#00A19A] border-l-[3px] rounded-lg w-full md:w-[280px] flex flex-col items-start">
  <div className="flex items-center mb-2">
  <BiMoon
   size={18}
   className="rounded-lg w-4 h-4"
      alt="route"
    />
    <text className="text-[14px] font-bold ml-2">
      Activity
    </text>
  </div>
  <div className="ml-2">
    <div>
      <text className="text-[10px] ">
      <span style={{ fontSize: '12px',fontWeight: 'normal' }}> {item.morning.activity}</span>

        <br />
        <span style={{ fontSize: '10px',fontWeight: 'normal' }}> {item.morning.breakfast}</span>

      
      </text>
    </div>
  </div>
</div>

                
          
                
              </div>
          
            </div>
          ))}
     
  
              
              
            </div>
            
            ) : (
             
              <div>Creating Your Itinerary... 
                
             
                
    <CircularProgress size={12} sx={{ color: 'black' }} /></div>
            )}

          </div>
        </div>
          
      </div>

    </>
  );
};

export default DIYOverviewPage;
