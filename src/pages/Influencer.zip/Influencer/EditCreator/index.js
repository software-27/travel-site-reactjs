import React, { useState, useRef } from 'react'
import axios from 'axios';
import HeaderOTA from 'components/Header/HeaderOTA/index';
import App from 'pages/Influencer/App/index';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import './editcreator.css';
import { ImFacebook2, ImFacebook, ImTwitter, ImInstagram } from 'react-icons/im';
import { FaTwitterSquare, FaInstagram, FaTiktok } from 'react-icons/fa';
import { TfiYoutube } from 'react-icons/tfi';
import { IoShare } from 'react-icons/io5';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import LoadingSpinner from 'components/LoadingSpinner/index';
import { useEffect } from 'react';
import { Modal, initTE } from 'tw-elements';
import { Line } from 'components/Line/index';
// import { useAuth } from 'AuthContext';

// Initialize tw-elements
initTE({ Modal });

const EditCreator = () => {

  const [name, setName] = useState('');
  const [keywords, setKeywords] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [language, setLanguage] = useState('');
  const [description, setDescription] = useState('');
  const [showSavedText, setShowSavedText] = useState(false);
  const [generatedDescription, setGeneratedDescription] = useState('');
  const editorRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  // const { setIsLoggedIn } = useAuth();
  const [isModalOpen, setModalOpen] = useState(false);

  const [logoImagePath, setLogoImagePath] = useState('');
  const [headerImagePath, setHeaderImagePath] = useState('');
  const [profileImagePath, setProfileImagePath] = useState('');

  const [logoImage, setLogoImage] = useState('');
  const [headerImage, setHeaderImage] = useState('');
  const [profileImage, setProfileImage] = useState('');

  const [profileData, setProfileData] = useState({
    bio: '',
    instagram: '',
    tiktok: '',
    twitter: '',
    facebook: '',
    youtube: '',
    username: '',
    email: '',
  });

  const [headerImageExists, setHeaderImageExists] = useState(true);
  const [profileImageExists, setProfileImageExists] = useState(true);
  const defaultHeaderImageUrl = 'images/default_header.jpg';
  const defaultProfileImageUrl = 'images/default_profile.jpg';

  // setIsLoggedIn(true);

  const handleLogoImageChange = (event) => {
    const file = event.target.files[0];
    setLogoImage(file);
  };

  const handleHeaderImageChange = (event) => {
    const file = event.target.files[0];
    setHeaderImage(file);
  };

  const handleProfileImageChange = (event) => {
    const file = event.target.files[0];
    setProfileImage(file);
  };

  const handleImageRemove = (imageTypes) => {
    imageTypes.forEach((imageType) => {
      switch (imageType) {
        case 'logoImage':
          setLogoImage(null);
          break;
        case 'logoImagePath':
          setLogoImagePath(null);
          break;
        case 'headerImage':
          setHeaderImage(null);
          setHeaderImageExists(false);
          break;
        case 'headerImagePath':
          setHeaderImagePath(null);
          setHeaderImageExists(false);
          break;
        case 'profileImage':
          setProfileImage(null);
          setProfileImageExists(false);
          break;
        case 'profileImagePath':
          setProfileImagePath(null);
          setProfileImageExists(false);
          break;
        default:
          break;
      }
    });
  };

  const userId = localStorage.getItem("userId");

  useEffect(() => {
    // Fetch the current user's data from the database and populate the form fields
    axios.get(`https://halaltravel.ai/ht/api/profile/${userId}`)
      .then(response => {
        const data = response.data;
        const logoImage = data.logoImage;
        const headerImage = data.headerImage;
        const profileImage = data.profileImage;
        const bio = data.bio;
        setProfileData({
          email: data.email,
          username: data.userName,
          bio: data.bio,
          instagram: data.instagram,
          tiktok: data.tiktok,
          facebook: data.facebook,
          twitter: data.twitter,
          youtube: data.youtube,
        });
        setLogoImagePath(logoImage);
        setHeaderImagePath(headerImage);
        setProfileImagePath(profileImage);
        setDescription(bio);
        console.log('-------------', data.profileImage);
      })
      .catch(error => {
        console.error('Error fetching profile data:', error);
      });
  }, [userId]);

  const handleInputChange = e => {
    const { name, value } = e.target;
    setProfileData({
      ...profileData,
      [name]: value,
    });
  };

  const handleSubmit = async () => {

    const json = JSON.stringify(profileData);
    const blob = new Blob([json], {
      type: 'application/json'
    });
    const formData = new FormData();
    formData.append('logoImage', logoImage);
    formData.append('headerImage', headerImage);
    formData.append('profileImage', profileImage);
    formData.append('profileData', blob);

    const token = localStorage.getItem("token");
    const tokenType = localStorage.getItem("tokenType");
    const userId = localStorage.getItem("userId");

    try {
      await axios.post(`https://halaltravel.ai/ht/api/profile/${userId}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      console.log('Profile updated successfully:', formData);
    } catch (error) {
      console.error('Error updating profile:', error.response);
    }
  };

  console.log('[ name:', name, 'keywords: ', keywords, 'target_audience:', targetAudience,
    'language:', language, ']')

  const generateProfileDescription = async () => {
    // Check if any of the required fields is empty
    if (!name || !keywords || !targetAudience || !language) {
      alert('Please fill in all fields');
      return;
    }
    setIsLoading(true);
    const payload = {
      name: name,
      keywords: keywords,
      target_audience: targetAudience,
      language: language,
    };

    try {
      const response = await axios.post('https://halaltravel.ai/gpt/creator', payload);
      // const generatedDescription = response.data.replace(/(<([^>]+)>)/gi, '');
      const generatedDescription = response.data.replace(/<\/?[^>]+(>|$)/g, '');
      setDescription(generatedDescription);
      setProfileData((prevData) => ({
        ...prevData,
        bio: generatedDescription, // Set for the "description" field in profileData
      }));
      // setGeneratedDescription(generatedDescription);
      // setShowSavedText(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTextAreaChange = (event) => {
    const data = event.target.value;
    setDescription(data);
    setProfileData((prevData) => ({
      ...prevData,
      bio: data
    }));
    console.log(data);
  };

  useEffect(() => {
    // Simulate loading delay with setTimeout (replace with your actual data fetching logic)
    const loadingDelay = setTimeout(() => {
      setIsLoading(false); // Set isLoading to false after the data is fetched (or simulated delay)
    }, 2000); // Adjust the delay as needed

    return () => clearTimeout(loadingDelay);
  }, []);


  const toggleModal = () => {
    setModalOpen(!isModalOpen);
  };


  const renderHeaderImage = () => {
    if (headerImagePath || headerImage) {
      return (
        <div className="relative">
          <button
            className="absolute top-2 right-2 p-1 bg-[#808080] rounded-full text-white"
            style={{
              padding: 0,
              borderRadius: '50%',
              width: '25px',
              height: '25px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onClick={() => handleImageRemove(['headerImagePath', 'headerImage'])}
          >
            X
          </button>

          <img
            src={headerImage ? URL.createObjectURL(headerImage) : headerImagePath}
            alt="Header"
            className="max-w-full max-h-full m-auto"
            style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
          />
        </div>
      );
    } else {
      return (
        <img
          src={defaultHeaderImageUrl}
          alt="Default Header"
          className="max-w-full max-h-full m-auto"
          style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
        />
      );
    }
  };


  return (
    <div className='bg-[#E9EDED] flex flex-col font-montserrat mx-auto w-full '>
      <HeaderOTAAdmin />
      {/* <HeaderOTAMobile /> */}
      <div className='flex flex-direction'>
        <div className='lg:w-[500px] xs:w-[300px] h-auto bg-[#D3DDDC] overflow-y-scroll'>

          {/* logo */}
          <div className='p-4'>
            <div className='justify-center items-center text-center my-2'>
              <button
                className='bg-[#00A19A] text-black font-medium px-5 py-1 text-sm items-center mb-3'
              >
                <span>Publish Your Storefront</span>
              </button>
            </div>

            {/* <p className='font-bold'>Logo Image</p>
            <label htmlFor="dropzone-file">
              <div className='w-full border border-[#A0A0A0] border-dashed text-center justify-center items-center pt-5 h-30'>
                {/* Conditional rendering */}
            {/* {(logoImagePath || logoImage) ? (
                  <div className="relative">
                    <button
                      className="absolute top-2 right-2 p-1 bg-[#808080] rounded-full text-white"
                      style={{
                        padding: 0,
                        borderRadius: '50%',
                        width: '25px',
                        height: '25px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      onClick={() => handleImageRemove(['logoImagePath', 'logoImage'])}
                    >
                      X
                    </button>

                    <img
                      src={logoImage ? URL.createObjectURL(logoImage) : logoImagePath}
                      alt="Logo"
                      className="max-w-full max-h-full m-auto"
                      style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
                    />
                  </div>
                ) : (
                  <div className='overflow-hidden relative'>
                    <button
                      className='bg-[#00A19A] text-white text-center font-medium px-5 py-1 rounded-lg text-[10px] items-center mb-3'
                      onClick={() => document.getElementById('logoImageInput').click()} // Trigger the input click

                    >
                      {/* <span>Select Image</span> */}
            {/* <span>{logoImagePath ? 'Change Image' : 'Select Image'}</span>
                    </button>
                    <p className='text-center'>File should be .jpeg or.png</p>
                    <input
                      id="logoImageInput"
                      type="file"
                      className="hidden"
                      name="logoImage"
                      onChange={handleLogoImageChange}
                    />
                  </div>
                )}
              </div>  */}
            {/* </label> */}

          </div>


          {/* header */}
          <div className='p-4'>
            <p className='font-bold'>Header Image</p>
            <label for="dropzone-file" >
              <div className='w-full border border-[#A0A0A0] border-dashed text-center justify-center items-center  h-30'>
                {/* Conditional rendering */}
                {(headerImagePath || headerImage) ? (
                  <div className="relative">
                    <button
                      className="absolute top-2 right-2 p-1 bg-[#808080] rounded-full text-white"
                      style={{
                        padding: 0,
                        borderRadius: '50%',
                        width: '25px',
                        height: '25px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      onClick={() => handleImageRemove(['headerImagePath', 'headerImage'])}
                    >
                      X
                    </button>

                    <img
                      src={headerImage ? URL.createObjectURL(headerImage) : headerImagePath}
                      alt="Header"
                      className="max-w-full max-h-full m-auto"
                      style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
                    />
                  </div>
                ) : (

                  <div className='overflow-hidden relative'>
                    <button
                      className='bg-[#00A19A] text-white text-center font-medium px-5 py-1 rounded-lg text-[10px] items-center mb-3'
                      onClick={() => document.getElementById('headerImageInput').click()} // Trigger the input click
                      style={{ marginTop: '20px' }}
                    >
                      {/* <span>Select Image</span> */}
                      <span>{headerImagePath ? 'Change Image' : 'Select Image'}</span>
                    </button>

                    <p className='text-center'>File should be .jpeg or.png</p>
                    <input
                      id="headerImageInput"
                      type="file"
                      className="hidden"
                      onChange={handleHeaderImageChange}
                    />

                  </div>

                )}

              </div>


            </label>

          </div>


          {/* profile */}
          <div className='p-4'>
            <p className='font-bold'>Profile Image</p>
            <label for="dropzone-file">

              <div className='w-full border border-[#A0A0A0] border-dashed text-center justify-center items-center h-30'>
                {/* Conditional rendering */}
                {(profileImagePath || profileImage) ? (
                  <div className="relative">
                    <button
                      className="absolute top-2 right-2 p-1 bg-[#808080] rounded-full text-white"
                      style={{
                        padding: 0,
                        borderRadius: '50%',
                        width: '25px',
                        height: '25px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      onClick={() => handleImageRemove(['profileImagePath', 'profileImage'])}
                    >
                      X
                    </button>

                    <img
                      src={profileImage ? URL.createObjectURL(profileImage) : profileImagePath}
                      alt="Profile"
                      className="max-w-full max-h-full m-auto"
                      style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
                    />
                  </div>
                ) : (


                  <div className='overflow-hidden relative'>
                    <button
                      className='bg-[#00A19A] text-white text-center font-medium px-5 py-1 rounded-lg text-[10px] items-center mb-3'
                      onClick={() => document.getElementById('profileImageInput').click()} // Trigger the input click
                      style={{ marginTop: '20px' }}
                    >
                      {/* <span>Select Image</span> */}
                      <span>{profileImagePath ? 'Change Image' : 'Select Image'}</span>
                    </button>

                    <p className='text-center'>File should be .jpeg or.png</p>
                    <input
                      id="profileImageInput"
                      type="file"
                      className="hidden"
                      onChange={handleProfileImageChange}
                    />
                  </div>
                )}
              </div>
            </label>
          </div>

          {/* details */}
          <form>
            <div className='p-4'>
              <div className=''>
                <label for='name' className='font-bold'>Name:</label>
                <input
                  type='text'
                  id="name"
                  placeholder='Your Name' requ
                  className='text-xs py-1 w-full rounded-lg'
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className='mt-4'>
                <label for='keywords' className='font-bold'>Keywords:</label>
                <textarea
                  type='text'
                  id="keywords"
                  className='text-xs w-full h-20 rounded-lg'
                  placeholder='Add anything about yourself'
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  required
                ></textarea>
              </div>
              <div className='mt-4'>
                <label for='target-audience' className='font-bold'>Targets Audience:</label>
                <textarea
                  type='text'
                  id="targetAudience"
                  className='text-xs py-1 w-full h-20 rounded-lg'
                  placeholder='For example, they can be fans of travel, people shopping for sports gear.'
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  required
                ></textarea>
              </div>
              <div className='mt-4'>
                <label for='language' className='font-bold'>Select Language:</label>
                <select
                  id='languages'
                  className='ml-5 py-1 text-xs items-left rounded-lg'
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  required
                >
                  <option value=''>Select</option>
                  <option value='en'>English</option>
                  <option value='ms'>Malay</option>
                  <option value='zh-Hans'>Chinese Simplified</option>
                  <option value='zh-Hant'>Chinese Tradition</option>
                </select>
              </div>
              <div className='mt-10 justify-center items-center text-center'>
                <button
                  className='bg-[#00A19A] text-white font-medium focus:bg-black focus:text-white px-5 py-1 rounded-lg text-sm items-center mb-3'
                  type='button'
                  onClick={generateProfileDescription}
                >
                  <span>Generate</span>
                </button>
              </div>
              {isLoading && (
                <div className="flex justify-center">
                  <LoadingSpinner />
                </div>
              )}
            </div>
          </form>

          {/* social media */}
          <div className='p-4'>
            <p className='font-bold'>Connect Social Accounts</p>
            <div className='mt-4'>
              <span className='font-medium'>Instagram</span>
              <input type='text' placeholder='https://instagram.com/#####' className='text-xs py-1 w-full rounded-lg'
                name='instagram'
                value={profileData.instagram}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-4'>
              <span className='font-medium'>Tiktok</span>
              <input type='text' placeholder='https://www.tiktok.com/#####' className='text-xs py-1 w-full rounded-lg'
                name='tiktok'
                value={profileData.tiktok}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-4'>
              <span className='font-medium'>Twitter</span>
              <input type='text' placeholder='https://x.com/######' className='text-xs py-1 w-full rounded-lg'
                name='twitter'
                value={profileData.twitter}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-4'>
              <span className='font-medium'>Facebook</span>
              <input type='text' placeholder='https://www.facebook.com/######' className='text-xs py-1 w-full rounded-lg'
                name='facebook'
                value={profileData.facebook}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-4'>
              <span className='font-medium'>Youtube</span>
              <input type='text' placeholder='https://youtube.com/channel/####' className='text-xs py-1 w-full rounded-lg'
                name='youtube'
                value={profileData.youtube}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>

          {/* profile setting */}
          <div className='p-4'>
            <p className='font-bold'>Profile Setting Accounts:</p>
            <div className='mt-4'>
              <span className='font-medium'>Username:</span>
              <input type='text' placeholder='user_nick' className='text-xs py-1 w-full rounded-lg'
                name='username'
                value={profileData.username}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-4'>
              <span className='font-medium'>Email Address:</span>
              <input type='email' placeholder='testing@gmail.com' className=' text-xs py-1 w-full rounded-lg'
                name='email'
                value={profileData.email}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className='mt-6 justify-center items-center text-center'>
              <button
                className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-sm items-center mb-3'
                onClick={() => {
                  toggleModal();
                  handleSubmit();
                }}
              >
                <span>Save</span>
              </button>
            </div>
          </div>

          {isModalOpen && (
            <div
              data-te-modal-init
              className="fixed left-0 top-0 z-[1055] flex items-center justify-center w-full h-full bg-gray-500 bg-opacity-70"
            >
              <div
                data-te-modal-dialog-ref
                className="min-[576px] max-w-[500px] w-full mx-4 bg-white rounded-md shadow-lg"
              >
                {/* Modal Content */}
                <div className="p-4">
                  <h5 className="text-xl font-medium leading-normal text-gray-800">
                    Profile has been successfully updated </h5>
                  {/* Add your modal content here */}
                  <p className="text-sm text-gray-600">Go to
                    <a href="/influencer-creator" className="text-black font-bold"> My Storefront
                    </a>
                  </p>

                </div>

                {/* Modal Footer */}
                <div className="flex justify-end p-4 bg-gray-100 rounded-b-md">
                  <button
                    type="button"
                    onClick={toggleModal}
                    className="mr-2 inline-block bg-[#00A19A] px-6 py-2 text-xs font-medium uppercase leading-normal text-white hover:text-white bg-white-300 rounded hover:bg-gray-400 focus:outline-none focus:ring focus:ring-gray-400"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
        <div className='w-full'>
          {headerImageExists ? (
            <img
              src={headerImagePath ? headerImagePath : defaultHeaderImageUrl}
              className='object-cover xs:h-[30em] lg:h-auto w-full'
              style={{
                width: '1822px',
                height: '250px',
                objectFit: 'cover',
              }}
              alt="header" />
          ) : (
            <img
              src={defaultHeaderImageUrl}
              alt="Default Header"
              className="max-w-full max-h-full m-auto"
              style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
            />
          )}
          <div className='bg-white h-fit rounded-b-lg p-6'>
            <div className='image-container px-4 absolute xs:top-[360px] xs:left-[] lg:top-[250px] lg:left-[390px]'>
              {profileImageExists ? (
                <img
                  src={profileImagePath ? profileImagePath : defaultProfileImageUrl}
                  style={{
                    width: '200px', // Set the width to 200 pixels
                    height: '200px', // Set the height to 200 pixels
                    objectFit: 'cover', // Maintain aspect ratio and cover the entire container
                  }}
                  className='rounded-full items-start z-10 shadow-xl' />
              ) : (
                <img
                  src={defaultProfileImageUrl}
                  alt="Default Profile"
                  style={{
                    width: '200px', // Set the width to 200 pixels
                    height: '200px', // Set the height to 200 pixels
                    objectFit: 'cover', // Maintain aspect ratio and cover the entire container
                  }}
                  className='rounded-full items-start z-10 shadow-2xl'
                />
              )}
              <div className='inline-flex pl-[60px] space-x-2 py-2 mt-4'>
              </div>
            </div>

            <div className='profile-description pl-[230px] py-2 w-[100%]'>

              <textarea
                type="text"
                className="h-[150px] text-xs w-full focus:border-gray-500"
                placeholder='Tell your audience about youself'
                // value={description}
                // onChange={handleTextAreaChange}
                name='description'
                value={description && profileData.bio}
                onChange={handleTextAreaChange}

              />

            </div>
          </div>

          <div className='bg-white mt-3 w-full h-fit rounded-lg max-w-[1640px] m-auto'>
            <App />



          </div>


        </div>
      </div>
    </div>
  )
}

export default EditCreator;
