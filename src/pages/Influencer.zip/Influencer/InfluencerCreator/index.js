import React, { useState, useEffect } from 'react'
import { useNavigate } from "react-router-dom";
import HeaderOTA from 'components/Header/HeaderOTA/index';
import { ImFacebook2 } from 'react-icons/im';
import { FaTwitterSquare, FaInstagram, FaTiktok } from 'react-icons/fa';
import { TfiYoutube } from 'react-icons/tfi';
import { IoShare } from 'react-icons/io5';
import App from 'pages/Influencer/App/index';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import LinkBtn from 'components/linkBtn/index';
import { useAuth } from "AuthContext";
import axios from 'axios';
import { Line } from 'components/Line/index';


const InfluencerCreator = () => {
  const navigate = useNavigate();
  const [openTab, setOpenTab] = React.useState(1);
  const { setIsLoggedIn } = useAuth();

  const [headerImage, setHeaderImagePath] = useState('');
  const [profileImage, setProfileImagePath] = useState('');
  const [userName, setUsername] = useState('');
  const [instagram, setInstagram] = useState('');
  const [tiktok, setTiktok] = useState('');
  const [twitter, setTwitter] = useState('');
  const [facebook, setFacebook] = useState('');
  const [youtube, setYoutube] = useState('');
  const [bio, setBio] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isVisible, setIsVisible] = useState("");

  const defaultHeaderImageUrl = 'images/default_header.jpg';
  const defaultProfileImageUrl = 'images/default_profile.jpg';

  const changeHandler = e => {
    const getshow = e.target.value;
    setIsVisible(getshow);
  }

  const token = localStorage.getItem("token");
  const tokenType = localStorage.getItem("tokenType");
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    axios.get(`https://halaltravel.ai/ht/api/profile/${userId}`)
      .then(response => {

        const data = response.data;
        const headerImage = data.headerImage;
        const profileImage = data.profileImage;
        const userName = data.userName;
        const bio = data.bio;
        const instagram = data.instagram;
        const tiktok = data.tiktok;
        const facebook = data.facebook;
        const twitter = data.twitter;
        const youtube = data.youtube;

        setHeaderImagePath(headerImage);
        setProfileImagePath(profileImage);
        setUsername(userName);
        setBio(bio);
        setInstagram(instagram);
        setTiktok(tiktok);
        setFacebook(facebook);
        setTwitter(twitter);
        setYoutube(youtube);
        setLoading(false);
      })
      .catch(error => {
        setError(error);
        setLoading(false);
        console.error('Error fetching profile data:', error);
      });
  }, [userId]);

  const navigateToSocialAccount = (url) => {
    if (url) {
      window.open(url, '_blank');
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  const handleEditProfileClick = () => {
    navigate('/edit-creator');
  };

  setIsLoggedIn(true); // Update the isLoggedIn state

  return (
    <div className='bg-[#E9EDED] flex flex-col font-montserrat mx-auto w-full '>
      <HeaderOTAAdmin />
      {/* <HeaderOTAMobile /> */}
      <div className='w-full px-32 xs:px-0 lg:px-20'>
        {headerImage ? (
          <img
            src={`${headerImage}`}
            className='object-cover xs:h-[30em] lg:h-auto w-full'
            style={{
              width: '1822px',
              height: '320px',
              objectFit: 'cover',
            }}
            alt="Header"
          />
        ) : (
          <div>
            <img
              src={defaultHeaderImageUrl}
              className='object-cover xs:h-[30em] lg:h-auto w-full'
              style={{
                width: '1822px',
                height: '300px',
                objectFit: 'cover',
              }}
              alt="Default Header"
            />
            <Line className='w-[100%] bg-black absolute' />
            <hr />
          </div>

        )}
        <div className='bg-white h-fit rounded-b-lg p-2 px-6'>
          <div className='image-container px-4 absolute xs:top-[360px] xs:left-[] lg:top-[291px] lg:left-[90px]'>
            {profileImage ? (
              <img
                src={`${profileImage}`}
                alt="Profile"
                height='200px' width='200px'
                style={{
                  width: '250px', // Set the width to 200 pixels
                  height: '250px', // Set the height to 200 pixels
                  objectFit: 'cover', // Maintain aspect ratio and cover the entire container
                }}
                className='rounded-full items-start z-10 drop-shadow-lg' />
            ) : (
              <img
                src={defaultProfileImageUrl}
                alt="Profile"
                height='200px' width='200px'
                style={{
                  width: '250px', // Set the width to 200 pixels
                  height: '250px', // Set the height to 200 pixels
                  objectFit: 'cover', // Maintain aspect ratio and cover the entire container
                }}
                className='rounded-full items-start z-10 drop-shadow-lg' />
            )}
          </div>
          <div className='profile-description pl-[300px] pr-[45px] py-2 w-[100%] text-gray-800'>
            <p className='font-bold text-[20px] text-gray'>
              {userName ? userName : 'username'}</p>
            <p className='text-[14px] text-justify'>
              {bio ? bio : 'Tell your audience about yourself'}

            </p>
            <div style={{ marginBottom: '60px' }}></div>
            <div className='mt-4 social-media justify-between flex py-2 w-[100%]'>
              <div className='flex space-x-2'>
                {instagram && (
                  <button
                    // className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                    onClick={() => navigateToSocialAccount(instagram)}
                  >
                    <FaInstagram className="text-[#00A19A] h-[20px] w-[20px]" />

                  </button>
                )}

                {tiktok && (
                  <button
                    // className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                    onClick={() => navigateToSocialAccount(tiktok)}
                  >
                    <FaTiktok className="text-[#00A19A] h-[19px] w-[19px]" />

                  </button>
                )}

                {twitter && (
                  <button
                    // className='bg-[#00A19A] text-black font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                    onClick={() => navigateToSocialAccount(twitter)}
                  >
                    <FaTwitterSquare className="text-[#00A19A] h-[20px] w-[20px]" />
                  </button>
                )}

                {facebook && (
                  <button
                    // className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                    onClick={() => navigateToSocialAccount(facebook)}
                  >
                    <ImFacebook2 className="text-[#00A19A] h-[19px] w-[19px]" />

                  </button>
                )}

                {youtube && (
                  <button
                    // className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                    onClick={() => navigateToSocialAccount(youtube)}
                  >
                    <TfiYoutube className="text-[#00A19A] h-[21px] w-[21px]" />

                  </button>
                )}
              </div>


              <div className='space-x-2 flex items-center justify-center'>
                <button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px] items-center'
                  onClick={handleEditProfileClick}
                >Edit Profile</button>
                <LinkBtn className="text-[#00A19A] h-[21px] w-[21px]" />
              </div>

            </div>
          </div>

        </div>

        <div className='bg-white mt-3 w-full h-fit rounded-lg max-w-[1640px] m-auto'>
          <App />
        </div>

      </div>
    </div>

  )
}

export default InfluencerCreator;