import React, {useState} from 'react'
import HeaderOTA from 'components/Header/HeaderOTA/index';
import { useNavigate } from '../../../../node_modules/react-router-dom/index';
import { MdOutlineDone } from 'react-icons/md';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';

const BlogOutline = () => {
//navigate button
const navigate = useNavigate();
function handleNavigate1() {
  navigate("/review-generate")
}
  // State to control the visibility of the content
  const [isContentVisible, setContentVisible] = useState(false);

  // Function to handle button click
  const handleButtonClick = () => {
    setContentVisible(true); // Set the visibility state to true on button click
  };

//select
const [selectedOption, setSelectedOption] = useState(null);

const handleOptionSelect = (option) => {
  setSelectedOption(option);
};

  return (
    <div className=' flex flex-col font-montserrat mx-auto w-full h-auto'>
    <HeaderOTAAdmin />
    {/* <HeaderOTAMobile /> */}
    <div className='w-full p-4'>

<div class="max-w-xl mx-auto my-4 ">	
	<div class="flex pb-3">
		<div class="flex-1">
		</div>

		<div class="flex-1 items-center">
			<div class="w-10 h-10 bg-[#38b000] items-center border-2 border-grey-light mx-auto rounded-full flex">
				<MdOutlineDone size={20} className='text-white ml-2' />
			</div>
		</div>


		<div class="w-3/4 align-center items-center align-middle content-center flex">
    <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
      <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[100%]"></div>
    </div>
		</div>
	
		
		<div class="flex-1">
			<div class="w-10 h-10 bg-gray-500 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
				<span class="text-white text-center w-full">2</span>
			</div>
		</div>
	
		<div class="w-3/4 align-center items-center align-middle content-center flex">
    <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
      <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
    </div>
		</div>
	
		<div class="flex-1">
			<button class="w-10 h-10 bg-gray-500/20 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
				<span class="text-white text-center w-full">3</span>
			</button>
		</div>
	
		<div class="flex-1">
		</div>		
	</div>
	
	<div class="flex text-sm content-center text-center">
		<div class="w-2/4 text-[#38b000]">
			Step 1: Blog Ideas + Titles
		</div>
		
		<div class="w-2/4">
			Step 2: Blog Outline
		</div>
		
		<div class="w-2/4 text-gray-500/30">
			Step 3: Review and Generate
		</div>
	</div>

  <div className='w-full content-center mt-4 sm:max-w-3xl'>
  <div className='border border-gray-200 rounded-sm shadow p-4 h-[fit] sm:max-w-3xl'>
    <text className='font-semibold text-lg'>Blog Outline</text>
    
	<div className='m-2 mt-2 gap-4 items-center'>
      <div className='w-[100%]'>
        <span className='font-medium'>Blog Title:</span>
        <input
          type='text'
          className='px-2 text-xs py-1 w-full h-fit rounded-lg focus:border-blue-500'
          placeholder='A 3-Day Tour of Melaka: Exploring the Historical City of Malaysia'
        />
      </div>
	  </div>
      <div>
		<div className='m-2 flex justify-end mt-3'>
			<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
			onClick={handleButtonClick}
			value='yes'>Generate</button>
		</div>
		{isContentVisible && (
			<div className='m-2 space-y-2'>
				<span className='font-medium'>Results:</span>
				<div className='text-xs w-full rounded-lg border border-gray-500'>
					<div className='p-4 space-y-2'>
					<span className='font-bold'>Blog Outline</span>
					<p className='text-justify'>1. Introduction: Overview of Melaka, Malaysia and why it is a great destination for a 3-day tour<br />
					2. Day 1: Explore the historical sites of Melaka a such as A Famosa, St Pauls's Church,
					and the Melaka Sultanate Palace Museum <br />
					3. Day 2: Visit the cultural attractions of Melaka such as Baba & Nyonya Heritage Museum,
					the Jonker Street night market, and the Cheng Hoon teng Temple <br/>
					4. Day 3: Sample the local cuisine of Melaka such as the famous Nyonya Laksa
					and Durian Cendol, and take a river cruise along the Melaka River <br/>
					5. Conclusion: Summary of the 3-day tour and tips for future
					travelers
					</p>
					</div>
				</div>
				<div className='mt-3 flex justify-end'>
					<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
					onClick={handleNavigate1}>Continue</button>
				</div>
			</div>
		)}
      </div>
  </div>
  </div>

</div>
    </div>                                    
</div>
    
  )
}

export default BlogOutline;