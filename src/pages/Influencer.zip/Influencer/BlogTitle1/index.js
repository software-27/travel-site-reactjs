import React, {useState} from 'react'
import { useNavigate } from "react-router-dom";
import { Text, Column, Row} from 'components';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';

const BlogTitle = () => {
//navigate button
const navigate = useNavigate();
function handleNavigate1() {
  navigate("/blog-outline")
}
  // State to control the visibility of the content
  const [isContentVisible, setContentVisible] = useState(false);

  // Function to handle button click
  const handleButtonClick = () => {
    setContentVisible(true); // Set the visibility state to true on button click
  };

//select
const [selectedOption, setSelectedOption] = useState(null);

const handleOptionSelect = (option) => {
  setSelectedOption(option);
};

//  const changeHandler = e => {
//    const getshow = e.target.value;
//    setIsVisible(getshow);
//  }

  return (
    <div className=' flex flex-col font-montserrat mx-auto w-full h-auto'>
    <HeaderOTAAdmin />
    {/* <HeaderOTAMobile /> */}
    <div className='w-full p-4'>

<div class="max-w-xl mx-auto my-4 ">	
	<div class="flex pb-3">
		<div class="flex-1">
		</div>

		<div class="flex-1">
			<div class="w-10 h-10 bg-gray-500 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
				<span class="text-white text-center w-full">1</span>
			</div>
		</div>


		<div class="w-3/4 align-center items-center align-middle content-center flex">
    <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
      <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
    </div>
		</div>
	
		
		<div class="flex-1">
			<div class="w-10 h-10 bg-gray-500/30 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
				<span class="text-white text-center w-full">2</span>
			</div>
		</div>
	
		<div class="w-3/4 align-center items-center align-middle content-center flex">
    <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
      <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
    </div>
		</div>
	
		<div class="flex-1">
			<button class="w-10 h-10 bg-gray-500/30 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
				<span class="text-white text-center w-full">3</span>
			</button>
		</div>
	
		<div class="flex-1">
		</div>		
	</div>
	
	<div class="flex text-sm content-center text-center">
		<div class="w-2/4">
			Step 1: Blog Ideas + Titles
		</div>
		
		<div class="w-2/4 text-gray-500/50">
			Step 2: Blog Outline
		</div>
		
		<div class="w-2/4 text-gray-500/50">
			Step 3: Review and Generate
		</div>
	</div>

  <div className='w-full content-center mt-4 sm:max-w-3xl'>
  <div className='border border-gray-200 rounded-sm shadow p-4 h-[fit] sm:max-w-3xl'>
    <text className='font-semibold text-lg'>Blog Ideas + Titles</text>
    
    <div className='m-2 mt-2 grid grid-cols-2 gap-4'>
      <div className=''>
        <span className='font-medium'>Keywords:</span>
        <input type='text' placeholder='Enter keywords...' className='text-xs py-1 w-full rounded-lg focus:border-blue-500'></input>
      </div>
      <div className=''>
        <label for='language' className='font-medium'>Output Language:</label>
        <select
          id='languages'
          className='py-1 text-xs items-left rounded-lg focus:border-blue-500 w-full'
          required
        >

          <option value=''>Select</option>
          <option value='en'>English</option>
          <option value='ms'>Malay</option>
          <option value='zh-Hans'>Chinese Simplified</option>
          <option value='zh-Hant'>Chinese Tradition</option>
        </select>
      </div>
    </div>
    <div>
      <div className='m-2 flex justify-end mt-3'>
        <button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
        onClick={handleButtonClick}
        value='yes'>Generate</button>
      </div>
      {isContentVisible && (
    <div className='m-2 space-y-3'>
    <span className='font-medium'>Results:</span>
    <div className='space-y-2 justify-start'>
      <button
        className={`${
          selectedOption === 1 ? 'bg-gray-500' : 'bg-gray-300'
        } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
        onClick={() => handleOptionSelect(1) }
      >
      <p className='items-start'>A 3-Day Tour of Melaka: Exploring the Historical City of Malaysia</p>
      </button>
      <button
        className={`${
          selectedOption === 2 ? 'bg-gray-500' : 'bg-gray-300'
        } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
        onClick={() => handleOptionSelect(2)}
      >
      <p className='text-start'>3 Days in Melaka:  Uncovering the Rich Culture and History of Malaysia</p>
      </button>
      <button
        className={`${
          selectedOption === 3 ? 'bg-gray-500' : 'bg-gray-300'
        } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
        onClick={() => handleOptionSelect(3)}
      >
      <p className='text-start'>Exploring Melaka: A Guide to a 3-Day Tour of Malaysia's Cultural Hub</p>
      </button>
    </div>

    <p className='text-sm text-right'>Select 1 and Click Continue</p>
    <div className='flex justify-end'>
      <button
        className={`${
          selectedOption ? 'bg-[#00A19A]' : 'bg-gray-300'
        } text-white font-medium px-5 py-1 rounded-lg text-[10px]`}
        disabled={!selectedOption}
        onClick={handleNavigate1}
      >
        Continue
      </button>
    </div>
  </div>
      )}

    </div>

  </div>
  </div>

</div>
    </div>                                    
</div>
    
  )
}

export default BlogTitle;