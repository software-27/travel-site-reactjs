import React, { useState} from 'react'
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import { useLocation } from 'react-router-dom';
import LoadingSpinner from 'components/LoadingSpinner/index';

const BlogTitle = () => {
  //navigate button
  const navigate = useNavigate();
  const [keywords, setKeywords] = useState('');
  const [language, setLanguage] = useState('');
  const [generatedTitle, setGeneratedTitle] = useState('');
  const [selectedOption, setSelectedOption] = useState('');
  const [dataArray, setDataArray] = useState([]);
  const [dataOnlyArray, setDataOnlyArray] = useState([]);
  const location = useLocation();
  const [isContentVisible, setContentVisible] = useState(false);
  //spinner
  const [isLoading, setIsLoading] = useState(false);

  
  // useEffect(() => {
  //   // Retrieve values from localStorage on page load
  //   const storedKeywords = localStorage.getItem("keywords");
  //   const storedLanguage = localStorage.getItem("language");
  //   // const storedNewDataOnlyArray = localStorage.getItem("newDataOnlyArray");

  //   // Update state with stored values if they exist
  //   if (storedKeywords) {
  //     setKeywords(storedKeywords);
  //   }

  //   if (storedLanguage) {
  //     setLanguage(storedLanguage);
  //   }

  //   // if (storedNewDataOnlyArray) {
  //   //   setDataOnlyArray(storedNewDataOnlyArray);
  //   // }

  //   console.log('storedKeywords: ', storedKeywords)
  //   console.log('storedLanguage: ', storedLanguage)
  //   // console.log('storedNewDataOnlyArray: ', storedNewDataOnlyArray)

  // }, []);


  const generateBlogTitle = async () => {

    console.log('[ keywords: ', keywords, "||", 'language:', language, ']')

    // Check if any of the required fields is empty
    if (!keywords || !language) {
      alert('Please fill in all fields');
      return;
    }

    const payload = {
      keywords: keywords,
      language: language,
    };

    try {
      setIsLoading(true); // Show the loading spinner
      const response = await axios.post('https://halaltravel.ai/gpt/blog/partone', payload);
      // setGeneratedTitle(response.data.titles);
      setIsLoading(false); // Hide the loading spinner after the API call is complete
      setGeneratedTitle(response.data)
      setContentVisible(true);
      console.log("Results:" + response.data);

      // Split the generatedTitle into an array using newline characters
      const newArray = response.data.split('\n').map(item => item.trim('"'));
      // Extract only the blog titles from the newArray
      // const newDataOnlyArray = newArray.map(item => item.split('"')[1]);
      // const newDataOnlyArray = newArray.map(item => item.replace(/^\d+\.\s*/, ''));
      const newDataOnlyArray = newArray.map(item => item.replace(/^\d+\.\s*"?|"$/g, ''));
      // Update the state with the array of blog titles
      setDataArray(newDataOnlyArray);
      // Make sure the dataArray has at least three elements
      if (newDataOnlyArray.length >= 3) {
        const [data1, data2, data3] = newDataOnlyArray;
        console.log('Result 1:', data1);
        console.log('Result 2:', data2);
        console.log('Result 3:', data3);
      } else {
        console.log('Not enough data to split into three elements');
      }      
      // localStorage.setItem('keywords', keywords);
      // localStorage.setItem('language', language);
      // Update the state dataOnlyArray with newDataOnlyArray
      setDataOnlyArray(newDataOnlyArray);
      // localStorage.setItem('newDataOnlyArray', newDataOnlyArray);

    } catch (error) {
      console.error(error);
      setIsLoading(false); // Hide the loading spinner in case of an error
    }

  };

  // continue button
  function handleNavigate1() {
    // navigate("/blog-outline1", { state: { selectedTitle: dataOnlyArray[selectedOption - 1] } });
    navigate("/blog-outline", { state: { selectedTitle: selectedOption ? dataOnlyArray[selectedOption - 1] : "" } });
    // navigate("/blog-outline1")
    
  };
  //for dropdown list
  const [isVisible, setIsVisible] = useState("");


  const handleOptionSelect = (option) => {
    setSelectedOption(option);
  };

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const changeHandler = e => {
    const getshow = e.target.value;
    setIsVisible(getshow);
  }

  return (
    <div className=' flex flex-col font-montserrat mx-auto w-full h-auto'>
      <HeaderOTAAdmin />
      {/* <HeaderOTAMobile /> */}
      <div className='w-full p-4'>

        <div class="max-w-xl mx-auto my-4 ">
          <div class="flex pb-3">
            <div class="flex-1">
            </div>

            <div class="flex-1">
              <div class="w-10 h-10 bg-gray-500 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
                <span class="text-white text-center w-full">1</span>
              </div>
            </div>


            <div class="w-3/4 align-center items-center align-middle content-center flex">
              <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
              </div>
            </div>


            <div class="flex-1">
              <div class="w-10 h-10 bg-gray-500/30 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
                <span class="text-white text-center w-full">2</span>
              </div>
            </div>

            <div class="w-3/4 align-center items-center align-middle content-center flex">
              <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                <div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
              </div>
            </div>

            <div class="flex-1">
              <button class="w-10 h-10 bg-gray-500/30 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
                <span class="text-white text-center w-full">3</span>
              </button>
            </div>

            <div class="flex-1">
            </div>
          </div>

          <div class="flex text-sm content-center text-center">
            <div class="w-2/4">
              Step 1: Blog Ideas + Titles
            </div>

            <div class="w-2/4 text-gray-500/50">
              Step 2: Blog Outline
            </div>

            <div class="w-2/4 text-gray-500/50">
              Step 3: Review and Generate
            </div>
          </div>

          <div className='w-full content-center mt-4 sm:max-w-3xl'>
            <div className='border border-gray-200 rounded-sm shadow p-4 h-[fit] sm:max-w-3xl'>
              <text className='font-semibold text-lg'>Blog Ideas + Titles</text>

              <div className='m-2 mt-2 grid grid-cols-2 gap-4'>
                <div className=''>
                  <span className='font-medium'>Keywords:</span>
                  <input type='text' placeholder='Enter keywords...' className='text-xs py-1 w-full rounded-lg focus:border-blue-500'
                    id="keywords"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    required
                  ></input>
                </div>
                <div className=''>
                  <label for='language' className='font-medium'>Output Language:</label>
                  <select
                    id='languages'
                    className='py-1 text-xs items-left rounded-lg focus:border-blue-500 w-full'
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    required
                  >
                    <option value=''>Select</option>
                    <option value='en'>English</option>
                    <option value='ms'>Malay</option>
                    <option value='zh-Hans'>Chinese Simplified</option>
                    <option value='zh-Hant'>Chinese Tradition</option>
                  </select>
                </div>
              </div>
              <div className='m-2 flex justify-end mt-3'>
                <button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
                  type='button'
                  onClick={() => {
                    generateBlogTitle();
                  }}
                  value = 'yes'>Generate</button>
              </div>
              {/* Loading spinner will be rendered conditionally */}
              {isLoading && (
                        <div className="flex justify-center"> {/* Center the spinner using flex */}
                          <LoadingSpinner />
                        </div>
                      )}

              {isContentVisible && (
              <div className='m-2 space-y-3'>
                <span className='font-medium'>Results:</span>
                <div className='space-y-2 justify-start'>
                  {dataOnlyArray.length >= 1 && (
                    <>

                      <button
                        className={`${selectedOption === 1 ? 'bg-gray-500' : 'bg-gray-300'
                          } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
                        onClick={() => handleOptionSelect(1)}
                      >
                        <p className='items-start'>{dataOnlyArray[0]}</p>
                      </button>
                    </>
                  )}

                  {dataOnlyArray && dataOnlyArray.length >= 2 && (
                    <button
                      className={`${selectedOption === 2 ? 'bg-gray-500' : 'bg-gray-300'
                        } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
                      onClick={() => handleOptionSelect(2)}
                    >
                      <p className='text-start'>{dataArray[1]}</p>

                    </button>
                  )}

                  {dataArray && dataArray.length >= 3 && (
                    <button
                      className={`${selectedOption === 3 ? 'bg-gray-500' : 'bg-gray-300'
                        } text-black font-medium hover:bg-gray-500 rounded-lg w-full items-start p-3`}
                      onClick={() => handleOptionSelect(3)}
                    >
                      <p className='text-start'>{dataArray[2]}</p>
                    </button>
                  )}
                </div>



                <p className='text-sm text-right'>Select 1 and Click Continue</p>
                <div className='flex justify-end'>
                  <button
                    className={`${selectedOption ? 'bg-[#00A19A]' : 'bg-gray-300'
                      } text-white font-medium px-5 py-1 rounded-lg text-[10px]`}
                    disabled={!selectedOption}
                    onClick={handleNavigate1}
                  >
                    Continue
                  </button>
                </div>
              </div>
              )}


            </div>
          </div>

        </div>

      </div>
    </div >

  )
}

export default BlogTitle;