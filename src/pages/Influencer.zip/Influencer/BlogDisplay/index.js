
import HeaderOTA from 'components/Header/HeaderOTA/index';
import React, { useState } from 'react'
import { MdOutlineDone } from 'react-icons/md';
// import './cke.css';
import { useNavigate } from '../../../../node_modules/react-router-dom/index';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import { useLocation } from 'react-router-dom';
import LoadingSpinner from 'components/LoadingSpinner/index';
import { useEffect } from 'react';
import GlobalConstant from "constant/global";
import axios from "axios";
import { useAuth } from "AuthContext";

const BlogDisplay = () => {
	const [isLoading, setIsLoading] = useState(false);
	const location = useLocation();
	// const { generatedBlogData: generatedBlogData } = location.state || {};
	// const { generatedBlogData: generatedBlogData } = location.state || {};
	const [blogContent, setBlogContent] = useState('');
	// const { blogId } = location.state || {};


	//navigate button
	const navigate = useNavigate();


	//for dropdown list
	const [isVisible, setIsVisible] = useState("");

	//select
	const [selectedOption, setSelectedOption] = useState(null);

	const handleOptionSelect = (option) => {
		setSelectedOption(option);
	};

	const changeHandler = e => {
		const getshow = e.target.value;
		setIsVisible(getshow);
	}

	const userId = useLocation().pathname.replace('/blog-display/','').split('/')[0];
	const blogId = useLocation().pathname.replace(`/blog-display/`,'').split('/')[1];
	const blogTitle = useLocation().pathname.replace(`/blog-display/`,'').split('/')[2];
	// const blogTitle = useLocation().pathname.replace(`/blog-display/${userId}/${blogId}/`,'');
	// const currentPath = useLocation().pathname;
	console.log('userId: ',userId);
	console.log('blogId: ',blogId);
	console.log('blogTitle: ',blogTitle);
	// const tempUserId = "";
	// localStorage.setItem("tempUserId", currentPath);


	useEffect(() => {
		//const blogId = localStorage.getItem("blogId");
		console.log("blogId:  " + blogId);
		if (blogId) {
			const fetchBlogContent = async () => {
				try {
					const response = await axios.get(`https://halaltravel.ai/ht/api/blog/blogDetails/${blogId}`);
					console.log("Response:" + response.data);
					setBlogContent(response.data.blog);
				} catch (error) {
					console.error('Error fetching blog content:', error);
				}
			};

			fetchBlogContent();
		}
	}, [blogId]);

	const { setIsLoggedIn } = useAuth(); 
	setIsLoggedIn(true);


	return (
		<div className=' flex flex-col mx-auto w-full h-auto '>
			<HeaderOTAAdmin />
			{/* <HeaderOTAMobile /> */}
			<div className='mx-72'>

				<div className='mt-8 border border-2 border-[] rounded-sm shadow p-10 px-20 py-10 h-[fit]'>
					{blogContent ? (
						<div dangerouslySetInnerHTML={{ __html: blogContent }} />
					) : (
						<div className='flex items-center justify-center h-full'>
							<LoadingSpinner />
						</div>
					)}

				</div>
			</div>

		</div>

	)
}

export default BlogDisplay;