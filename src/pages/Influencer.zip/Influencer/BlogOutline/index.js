import React, { useState} from 'react'
import axios from 'axios';
import HeaderOTA from 'components/Header/HeaderOTA/index';
import { useNavigate } from '../../../../node_modules/react-router-dom/index';
import { MdOutlineDone } from 'react-icons/md';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import { useLocation } from 'react-router-dom';
import LoadingSpinner from 'components/LoadingSpinner/index';

const BlogOutline = () => {
	const location = useLocation();
	const selectedTitle = location.state && location.state.selectedTitle;
	// State for editable blog title
	const [title, setTitle] = useState(selectedTitle || '');
	const [blogOutline, setBlogOutline] = useState('');
	//Generate Button
	const generateBlogOutline = async () => {

		console.log('[ blogTitle: ', title, ']')

		// Check if any of the required fields is empty
		if (!title) {
			alert('Please fill in blog title');
			return;
		}

		const payload = {
			title: title,
		};

		try {
			setIsLoading(true); // Show the loading spinner
			const response = await axios.post('https://halaltravel.ai/gpt/blog/parttwo', payload);
			setIsLoading(false); // Hide the loading spinner after the API call is complete
			setBlogOutline(response.data);
			setContentVisible(true);
			// Store the generated blog outline in localStorage
			// localStorage.setItem('blogOutline', response.data);
			console.log("Blog Outline:" + "\n" + response.data);
		}

		catch (error) {
			console.error(error);
			setIsLoading(false); // Hide the loading spinner in case of an error
		}

	};
	//navigate button
	const navigate = useNavigate();
	function handleNavigate1() {
		// navigate("/review-generate")
		navigate("/review-generate", { state: { title: title, blogOutline: blogOutline } });
		
	}
	//for dropdown list
	const [isVisible, setIsVisible] = useState("");

	// State to control the visibility of the content
	const [isContentVisible, setContentVisible] = useState(false);

	//spinner
	const [isLoading, setIsLoading] = useState(false);

	//select
	const [selectedOption, setSelectedOption] = useState(null);

	const handleOptionSelect = (option) => {
		setSelectedOption(option);
	};

	const changeHandler = e => {
		const getshow = e.target.value;
		setIsVisible(getshow);
	}

	// Function to handle changes in the blog title
	const handleTitleChange = (e) => {
		setTitle(e.target.value);
	};

	// // Check for stored blogOutline in localStorage when the component mounts
	// useEffect(() => {
	// 	const storedBlogOutline = localStorage.getItem('blogOutline');
	// 	if (storedBlogOutline) {
	// 		setBlogOutline(storedBlogOutline);
	// 		setContentVisible(true); // Set the visibility state to true when there's a stored blog outline
	// 	}
	// }, []);

	return (
		<div className=' flex flex-col font-montserrat mx-auto w-full h-auto'>
			<HeaderOTAAdmin />
			{/* <HeaderOTAMobile /> */}
			<div className='w-full p-4'>

				<div class="max-w-xl mx-auto my-4 ">
					<div class="flex pb-3">
						<div class="flex-1">
						</div>

						<div class="flex-1 items-center">
							<div class="w-10 h-10 bg-[#38b000] items-center border-2 border-grey-light mx-auto rounded-full flex">
								<MdOutlineDone size={20} className='text-white ml-2' />
							</div>
						</div>


						<div class="w-3/4 align-center items-center align-middle content-center flex">
							<div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
								<div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[100%]"></div>
							</div>
						</div>


						<div class="flex-1">
							<div class="w-10 h-10 bg-gray-500 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
								<span class="text-white text-center w-full">2</span>
							</div>
						</div>

						<div class="w-3/4 align-center items-center align-middle content-center flex">
							<div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
								<div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[0%]"></div>
							</div>
						</div>

						<div class="flex-1">
							<button class="w-10 h-10 bg-gray-500/20 border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
								<span class="text-white text-center w-full">3</span>
							</button>
						</div>

						<div class="flex-1">
						</div>
					</div>

					<div class="flex text-sm content-center text-center">
						<div class="w-2/4 text-[#38b000]">
							Step 1: Blog Ideas + Titles
						</div>

						<div class="w-2/4">
							Step 2: Blog Outline
						</div>

						<div class="w-2/4 text-gray-500/30">
							Step 3: Review and Generate
						</div>
					</div>

					<div className='w-full content-center mt-4 sm:max-w-3xl'>
						<div className='border border-gray-200 rounded-sm shadow p-4 h-[fit] sm:max-w-3xl'>
							<text className='font-semibold text-lg'>Blog Outline</text>

							<div className='m-2 mt-2 gap-4 items-center'>
								<div className='w-[100%]'>
									<span className='font-medium'>Blog Title:</span>
									<input
										type='text'
										className='px-2 text-xs py-1 w-full rounded-lg focus:border-blue-500'
										placeholder='Enter blog title...'
										value={title}
										onChange={handleTitleChange}
									/>
								</div>
							</div>
							<div>
								<div className='m-2 flex justify-end mt-3'>
									<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
										onClick={() => {
											generateBlogOutline();
										  }}
										value='yes'>Generate</button>
								</div>
								{/* Loading spinner will be rendered conditionally */}
								{isLoading && (
									<div className="flex justify-center"> {/* Center the spinner using flex */}
									<LoadingSpinner />
									</div>
								)}
								{isContentVisible && (
									<div className='m-2 space-y-2'>
										<span className='font-medium'>Results:</span>
										<div className='text-xs w-full rounded-lg border border-gray-500 bg-gray-200'>
											<div className='p-4 space-y-2'>
												<span className='font-bold'>Blog Outline</span>
												{/* <p className='text-justify'>{blogOutline}</p>
												 */}
												{blogOutline.split('\n').map((line, index) => (
													<p key={index} className='text-justify'>
														{line}</p>
												))}
											</div>
										</div>
										<div className='mt-3 flex justify-end'>
											<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
												onClick={handleNavigate1}>Continue</button>
										</div>
									</div>
								)}
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

	)
}

export default BlogOutline;