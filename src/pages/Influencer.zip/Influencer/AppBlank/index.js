import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { data, fetchBlogData, fetchProductData } from 'data/data';
import { Column, Row} from "components";
import { MdSearch } from 'react-icons/md';
import { AiOutlineDoubleRight } from 'react-icons/ai';
import { IoPricetagSharp } from 'react-icons/io5';
import { MdChevronLeft, MdChevronRight} from 'react-icons/md';
import { mdiBookmarkOutline} from '@mdi/js';
import { GrAddCircle } from 'react-icons/gr';
import { FaTimes } from 'react-icons/fa';
import { useEffect } from 'react';
import Icon from '@mdi/react';
import axios from "axios";
import { BsCalendarCheck } from "react-icons/bs";
import DatePicker from "react-datepicker";
import ThreeDotProd from 'components/ThreeDotProd/index';
import ThreeDotBlog from 'components/ThreeDotBlog/index';
import { RatingBar } from 'components/RatingBar/index';
import { Text } from 'components/index';
import { Img } from 'components/index';
import { ButtonMp } from 'components/index';

const AppBlank = () => {
  const [contents, setContents] = useState(data);
  const [blogContent, setBlogContent] = useState([]);
  const [productContent, setProductContent] = useState([]);
  const productId = '';
  const productCode = '';
  const productPin = '';
  const productLink = '';
  const navigate = useNavigate();
  const baseURL = window.location.origin;
  console.log("baseUrl: ", baseURL)
  
  //we need token, user id
  const token = localStorage.getItem("token");
  const tokenType = localStorage.getItem("tokenType");
  const userId = localStorage.getItem("tempUserId");

  //condition for each category
  const [isProduct, setIsProduct] = useState(false);
  const [isBlog, setIsBlog] = useState(false);
  const [isPhoto, setIsPhoto] = useState(false);
  const [isVideo, setIsVideo] = useState(false);
  const [isLivestream, setIsLivestream] = useState(false);
  const [isTravelplan, setIsTravelplan] = useState(false);

  // *Default value*
  useEffect(() => {
    setIsProduct(true);
    setIsBlog(true);
    setIsPhoto(true);
    setIsVideo(true);
    setIsLivestream(true);
    setIsTravelplan(true);
  }, []);

  //   Filter Type blog/photos/etc
  const filterType = (category) => {
    setContents(
      data.filter((filteredContent) => {
        return filteredContent.category === category;
      })
    );
  };


  const [currentPageProd, setCurrentPageProd] = useState(1);
  const [totalPagesProd, setTotalPagesProd] = useState('');
  // *Fetch Product Data*
  const fetchProduct = async () => {
    const pageSize = 4;
    try {
      const data = await fetchProductData(userId, currentPageProd, pageSize);
      if (data) {
        setProductContent(data.productContent);
        setTotalPagesProd(data.totalPages)
      }
    } catch (error) {
      console.error('Error fetching product data:', error);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, [currentPageProd])


  const [currentPageBlog, setCurrentPageBlog] = useState(1);
  const [totalPagesBlog, setTotalPagesBlog] = useState('');
  // *Fetch Blog Data*
  const fetchBlog = async () => {
    const pageSize = 5;
    try {
      const data = await fetchBlogData(userId, currentPageBlog, pageSize);
      if (data) {
        setBlogContent(data.blogContent);
        setTotalPagesBlog(data.totalPages)
      }
    } catch (error) {
      console.error('Error fetching blog data:', error);
    }
  };

  useEffect(() => {
    // fetchProduct();
    fetchBlog();
  }, [currentPageBlog]);

  console.log("Product Contents:", productContent);
  console.log("Blog Contents:", blogContent);
  console.log("Blog pages total:", totalPagesBlog);


  const [slideDirection, setSlideDirection] = useState(null);
  //*Slide product slider *
  const slideLeft = () => {
    // var slider = document.getElementById('slider')
    // slider.scrollLeft = slider.scrollLeft - 500
    if (currentPageProd > 1) {
      setCurrentPageProd(currentPageProd - 1);
    }
  }

  const slideRight = () => {
    // var slider = document.getElementById('slider')
    // slider.scrollLeft = slider.scrollLeft + 500
    setCurrentPageProd(currentPageProd + 1);
  }


  // * PAGINATION *
  const handleArrowClick = (direction) => {
    if (direction === 'left' && currentPageBlog > 1) {
      setCurrentPageBlog(currentPageBlog - 1);
    } else if (direction === 'right' && currentPageBlog < totalPagesBlog) {
      setCurrentPageBlog(currentPageBlog + 1);
    }
  };

  const getPageButtonsRange = () => {
    const buttonsRange = [];
    const startPage = Math.max(currentPageBlog - 1, 1);
    // const endPage = Math.min(currentPageBlog + 1, Math.ceil(totalPagesBlog));
    const endPage = Math.min(currentPageBlog, Math.ceil(totalPagesBlog));

    for (let i = startPage; i <= endPage; i++) {
      buttonsRange.push(i);
    }

    return buttonsRange;
  };

  // *CURRENCY*
  const currencySymbols = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    AUD: "$",
    AED: "د.إ",
    ARS: "$",
    BRL: "R$",
    CAD: "$",
    CHF: "CHF",
    CLP: "$",
    CNY: "¥",
    COP: "$",
    DKK: "kr",
    FJD: "FJ$",
    HHL: "HHL",
    HKD: "HK$",
    IDR: "Rp",
    ILS: "₪",
    INR: "₹",
    ISK: "kr",
    JPY: "¥",
    KRW: "₩",
    MXN: "$",
    MYR: "RM",
    NOK: "kr",
    NZD: "$",
    PEN: "S/",
    PHP: "₱",
    PLN: "zł",
    RUB: "₽",
    SEK: "kr",
    SGD: "$",
    THB: "฿",
    TRY: "₺",
    TWD: "NT$",
    VND: "₫",
    ZAR: "R",
  };;

  // * Change date format * // Format the date as "9 August 2023"
  const formatDate = (dateString) => {
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // const formatDate = (dateString) => {
  //   const options = { year: 'numeric', month: 'long', day: 'numeric' };
  //   return new Date(dateString).toLocaleDateString('en-US', options);
  // };


  // function handleReadMore(blogId) {
  //   navigate('/blog-display', { state: { blogId } });
  //   // navigate('/blog-display');
  // }

  function handleReadMore(blogId, blogTitle, userId) {
    navigate(`/blog-display/${userId}/${blogId}/${blogTitle}`);
    // navigate('/blog-display');
  }


  // * Navigation *
  function handleNavigate1() {
    navigate("/blog-title");
  }

  function handleNavigate2() {
    navigate("/tour-marketplace");
  }


  return (
    <div className='max-w-[1640px] m-auto px-4 p-12'>
      {/* <h1>Top Rated Menu Items</h1> */}

      {/* Filter Row */}
      <div className='flex flex-col lg:flex-row justify-between mb-6'>

        {/* Filter type */}
        <div className='flex flex-wrap'>
          <button
            onClick={() => {
              setContents(data);
              setIsProduct(true);
              setIsBlog(true);
              setIsPhoto(true);
              setIsVideo(true);
              setIsLivestream(true);
              setIsTravelplan(true);
            }}
            // className={`m-1 border ${isProduct ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>All</button>
            className={`m-1 border ${isProduct === true && isTravelplan === true && isBlog === true && isPhoto === true && isVideo === true && isLivestream === true ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>All</button>
          <button
            onClick={() => {
              filterType("itinerary");
              setIsProduct(false);
              setIsBlog(false);
              setIsPhoto(false);
              setIsVideo(false);
              setIsLivestream(false);
              setIsTravelplan(true);
            }}
            className={`m-1 border ${isProduct === false && isTravelplan === true && isBlog === false && isPhoto === false && isVideo === false && isLivestream === false ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>Travel Plan</button>
          <button
            onClick={() => {
              filterType('blog');
              setIsProduct(false);
              setIsBlog(true);
              setIsPhoto(false);
              setIsVideo(false);
              setIsLivestream(false);
              setIsTravelplan(false);
            }}
            // className='m-1 border border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white rounded-xl px-5 py-1'>Blog</button>
            className={`m-1 border ${isProduct === false && isTravelplan === false && isBlog === true && isPhoto === false && isVideo === false && isLivestream === false ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>Blog</button>
          <button
            onClick={() => {
              filterType('photos');
              setIsProduct(false);
              setIsBlog(false);
              setIsPhoto(true);
              setIsVideo(false);
              setIsLivestream(false);
              setIsTravelplan(false);
            }}
            // className='m-1 border border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white rounded-xl px-5 py-1'>Photos</button>
            className={`m-1 border ${isProduct === false && isTravelplan === false && isBlog === false && isPhoto === true && isVideo === false && isLivestream === false ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>Photos</button>
          <button
            onClick={() => {
              filterType('videos');
              setIsProduct(false);
              setIsBlog(false);
              setIsPhoto(false);
              setIsVideo(true);
              setIsLivestream(false);
              setIsTravelplan(false);

            }}
            // className='m-1 border border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white rounded-xl px-5 py-1'>Videos</button>
            className={`m-1 border ${isProduct === false && isTravelplan === false && isBlog === false && isPhoto === false && isVideo === true && isLivestream === false ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>Videos</button>
          <button
            onClick={() => {
              filterType('livestreams');
              setIsProduct(false);
              setIsBlog(false);
              setIsPhoto(false);
              setIsVideo(false);
              setIsLivestream(true);
              setIsTravelplan(false);

            }}
            // className='m-1 border border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white rounded-xl px-5 py-1'>Livestreams</button>
            className={`m-1 border ${isProduct === false && isTravelplan === false && isBlog === false && isPhoto === false && isVideo === false && isLivestream === true ? 'bg-teal-500 text-white' : 'border-teal-500 hover:bg-teal-500 hover:text-white focus:bg-[#00A19A] focus:text-white'} rounded-xl px-5 py-1`}>Livestreams</button>
        </div>

        {/* Searchbar */}
        <div className='flex gap-4'>
          <div className='bg-gray-200 justify-between rounded-full inline-flex items-center h-fit py-1 px-2 w-[200px] sm:w-[400px] lg:w-[500px]'>
            <input class='bg-transparent p-1 w-full focus:outline-none border-none'
              type='text' placeholder='Search' />
            <MdSearch className='text-[#00A19A]' size={20} />
          </div>

          <div className='items-center justify-center'>
            <button className='m-1 border border-[#00A19A] bg-[#00A19A] text-white rounded-xl px-5 py-1'>Search</button>
          </div>
        </div>

      </div>

      {/* Display contents */}
      <div>
        {/* product display /> */}
        <div className='relative items-center'>
          {isProduct ? (
            <>

              {/* <button className="absolute cursor-pointer top-[40%] left-2 bg-black bg-opacity-30 rounded-full w-6 h-6">
                <MdChevronLeft
                  className='text-white w-6 h-6'
                  onClick={slideLeft}
                  size={40}
                />
              </button> */}
              {currentPageProd > 1 && ( // Check if it's not the first page
                <button className="absolute cursor-pointer top-[40%] left-2 bg-black bg-opacity-30 rounded-full w-6 h-6">
                  <MdChevronLeft
                    className='text-white w-6 h-6'
                    onClick={slideLeft}
                    size={40}
                  />
                </button>
              )}

              <div className='flex justify-center'>
                <div id='slider'
                  className='w-[92%] h-[380px] inline-flex overflow-x-scroll scroll whitespace-nowrap scroll-smooth scrollbar-hide'
                >
                  {productContent.length === 0 ? (
                    <>
                      <div
                        className="inline-block p-5 cursor-pointer flex-shrink-0 relative hover:scale-105 duration-300 hover:text-teal-500"
                        onClick={handleNavigate2}
                      >
                        <div className='border rounded-lg shadow-lg h-[300px] w-[240px] flex flex-col justify-center'>

                          <div className="text-center text-xs font-bold">
                            Start tagging product
                            <img src="/images/img_arrowright_gray_700_01.svg" alt="Icon 1" className="ml-1 h-2 w-2 inline-flex" />
                          </div>

                        </div>
                      </div>
                      <div className="flex">
                        {[1, 2, 3].map((index) => (
                          <div key={index} className="inline-block p-5 flex-shrink-0 relative">
                            <div className="bg-gray-100 rounded-lg shadow-xs h-[300px] w-[240px] flex flex-col justify-center"></div>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    productContent.map((product) => (
                      <div key={product.productId} className="inline-block p-5 flex-shrink-0 relative hover:scale-105 duration-300" style={{ cursor: 'default' }}>
                        <div className='border rounded-lg shadow-lg w-[240px]'>
                          <a href={product.productLink} target="_blank" rel="noopener noreferrer">
                            <div className="relative inline-block flex">
                              {/* <span className='absolute mt-3 ml-3 bg-black bg-opacity-70 p-2 text-white font-bold text-xs shadow-md'>{currencySymbols[product.productCurrency]} {product.productPrice}</span> */}
                              <img
                                className='h-[200px] w-[240px] inline-block cursor-pointer rounded-t-lg'
                                src={product.productImage != null ? product.productImage : 'images/no_img_avail.jpg'}
                                alt={product.productName}
                                // title={product.productId}
                                title='Click to view product'
                              />
                              {product.productPin === 'PIN' && (
                                <span className="absolute top-0 left-0 bg-teal-700 w-[30%] shadow-lg rounded-tl-lg rounded-tr-xl rounded-br-xl cursor-pointer">
                                  <Text className="pl-2 text-xs text-white">PINNED</Text>
                                </span>
                              )}
                              {/* <button className="absolute top-0 right-2 cursor-pointer">
                                <ThreeDotProd fetchProduct={fetchProduct} userId={userId} productId={product.productId} productCode={product.productCode} productPin={product.productPin} productLink={product.productLink} />
                              </button> */}
                            </div>
                          </a>
                          <div className='p-3'>
                            <span
                              className='block max-w-[230px] h-[30px] font-bold text-black text-[13px] break-words whitespace-normal'
                              title={product.productName}
                            >
                              {product.productName
                                ? product.productName.length > 25
                                  ? product.productName.substring(0, 25) + '...'
                                  : product.productName
                                : 'Title not found'}
                            </span>
                            <span className='block max-w-[230px] h-[45px] text-gray text-[11px] break-words whitespace-normal'>
                              {product.productDesc
                                ? product.productDesc.substring(0, 60) + '... '
                                : '<No desc>'}
                              {product.productDesc && (
                                <a
                                  href={product.productLink}
                                  target="_blank"  // This opens the link in a new tab
                                  rel="noopener noreferrer" // This is recommended for security to prevent reverse tabnabbing
                                  className="font-montserrat text-left font-light underline cursor-pointer"
                                  style={{ color: 'blue', textDecorationColor: 'blue' }}
                                  title='More details'
                                >
                                  More
                                </a>
                              )}
                            </span>
                            <span className='block h-[15px] text-black text-[15px] font-bold break-words whitespace-normal flex justify-between items-center'>
                              <span>
                                {product.productCurrency === 'MYR' ? currencySymbols['USD'] : currencySymbols[product.productCurrency]}{' '}
                                {product.productCurrency === 'MYR' ? (product.productPrice * 0.2209907110425).toFixed(2) : product.productPrice}
                                {/* {currencySymbols[product.productCurrency]} {product.productPrice} */}
                                {/* , {product.productPin} */}
                              </span>
                              <span>
                                <RatingBar
                                  value={4.5}
                                  starCount={5}
                                  size={17}
                                />
                              </span>
                            </span>
                            <span className='flex justify-between items-center'>
                              {/* <span className='block h-[15px] mt-2 font-bold text-teal-700 text-[10px] break-words whitespace-normal text-left'>
                                <Text className='' title='https://epic.rezgo.com'>EPIC</Text>
                              </span> */}
                              <span className='block h-[15px] mt-2 font-bold text-teal-700 text-[10px] break-words whitespace-normal text-left'>
                                {product.productLink.includes("https://www.viator.com") ? (
                                  <Text className='' title='https://www.viator.com'>VIATOR</Text>
                                ) : product.productLink.includes("https://izzhnis.rezgo.com") ? (
                                  <Text className='' title='https://izzhnis.rezgo.com'>EPIC</Text>
                                ) : (
                                  <Text className='' title=''>OTHER</Text>
                                )}
                              </span>
                              <span className='block h-[15px] text-black text-[10px] break-words whitespace-normal text-right'>
                                <Text className=''>4.5/5 (10)</Text>
                              </span>
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* <button className="absolute cursor-pointer top-[40%] right-2 bg-black bg-opacity-30 rounded-full w-6 h-6">
                <MdChevronRight
                  className='text-white w-6 h-6'
                  onClick={slideRight}
                  size={40}
                />
              </button> */}
              {currentPageProd < totalPagesProd && ( // Check if it's not the last page
                <button className="absolute cursor-pointer top-[40%] right-2 bg-black bg-opacity-30 rounded-full w-6 h-6">
                  <MdChevronRight
                    className='text-white w-6 h-6'
                    onClick={slideRight}
                    size={40}
                  />
                </button>
              )}

            </>
          ) : null}
        </div>

        {/* Itinerary display */}
        <div>
          {isTravelplan ? (
            <>
            <p className="font-bold text-gray-700 m-2">Travel Plan</p>
          
          <div className="common-pointer h-[300px] grid md:grid-cols-2 lg:grid-cols-4 gap-6 pb-3">

            {contents
              .filter((data) => data.category === "itinerary")
              .map((filteredFood) => (
                <div>
                <div className='common-pointer h-[300px] border shadow-lg rounded-lg hover:scale-105 duration-300'>
                  <div className="relative inline-block flex">
                    <img
                      src={filteredFood.image}
                      alt={filteredFood.name}
                      title={filteredFood.name}
                      className="w-full h-[200px] object-cover rounded-t-lg"
                    />
                    {/* <button className='absolute top-1 right-2 cursor-pointer'>
                      <Icon path={mdiBookmarkOutline} 
                      size="30px" 
                      className="text-[#00A19A] bg-[#FFFFFF] w-fit h-fit p-1 hover:bg-[#00A19A] hover:text-[#FFFFFF] rounded-full common-pointer"/>
                    </button> */}
                  </div>
 
                    <div className="items-center gap-2 px-2 py-4">
                      <Row>
                      <p className="ml-3 justify-center font-bold w-fit"
                      title={filteredFood.name}
                      >
                        {filteredFood.name.length > 20 ? filteredFood.name.substring(0, 20) + '...' : filteredFood.name}
                      </p>
                     
                      </Row>
                      <p className="ml-3 mt-1 text-xs justify-center w-fit"
                      title={filteredFood.desc}
                      >
                         {filteredFood.desc.length > 40 ? filteredFood.desc.substring(0, 40) + '...' : filteredFood.desc}
                      </p>

                      <div className="justify-between ml-3 mt-[10px] flex">
                        <text className="text-[11px] italic text-[#000000]">
                          Aliahchase
                        </text>
                        <RatingBar
                          className="flex justify-between w-[70px]"
                          value={4}
                          starCount={5}
                          size={16}
                        />                     
                      </div>
                    </div>
                </div>
              </div>
              ))}
          </div>
          </>
          ) : null}
        </div>

        {/* blog display */}
        <div className='w-full mt-5 mb-5'>
          {isBlog ? (
            <>
              <p className='font-bold text-gray-700 m-2'>Blog</p>

              <div className='p-2 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-3' style={{ gridAutoRows: 'minmax(0, auto)' }}>

                {/* <div className='h-[470px] cursor-pointer border flex flex-col items-center justify-center shadow-lg rounded-lg hover:scale-105 duration-300'
                  onClick={handleNavigate1}>
                  <GrAddCircle size={25} className="items-center text-center" />
                  <p className='font-bold'>Create Your Blog</p>
                </div> */}

                {blogContent.length === 0 ? (
                  <>
                    <div className='h-[470px] bg-gray-100 rounded-lg shadow-xs'></div>
                    <div className='h-[470px] bg-gray-100 rounded-lg shadow-xs'></div>
                  </>
                ) : (
                  blogContent.map(blog => (
                    <div key={blog.blogId}>
                      <div className='h-[470px] border shadow-lg rounded-lg hover:scale-105 duration-300'>
                        <div className="relative inline-block flex">
                          <img
                            // src={filteredFood.image ? filteredFood.image : 'images/no_pic.png'}
                            src={blog.blogImage ? blog.blogImage : 'https://prod-virtuoso.dotcmscloud.com/dA/188da7ea-f44f-4b9c-92f9-6a65064021c1/heroImage1/PowerfulReasons_hero.jpg'}
                            className='w-full h-[200px] object-cover rounded-t-lg'
                          />
                          {/* <button className="absolute top-0 right-2 cursor-pointer">
                            <ThreeDotBlog 
                            fetchProduct={fetchProduct} 
                            userId={userId} 
                            blogLink={baseURL + `/blog-display/${userId}/${blog.blogId}/${encodeURIComponent(blog.blogTitle)}`} 
                            />
                          </button> */}
                        </div>

                        <div className='items-center justify-center px-2 py-4 h-[250px]'>
                          {/* <p className='text-center font-bold'>{blog.blog.match(/<h1>(.*?)<\/h1>/)?.[1] || 'Title not found'}</p> */}
                          <p className='text-center font-bold h-[20%]'>{blog.blogTitle}</p>
                          <p className='text-center opacity-70 h-[10%]'>{formatDate(blog.dateCreated)}</p>
                          {/* <p className='text-justify px-4'>{blog.blog.replace(/<h1[^>]*>.*?<\/h1>/i, "").replace(/<\/?[^>]+(>|$)/g, "").substring(0, 200)}...</p> */}
                          <p className='text-justify px-4 h-[45%]'>{blog.blogText.substring(0, 200)}...</p>
                          <p className='px-4 text-center mt-3 h-[10%]'>
                            <button className='inline-flex gap-1 items-center justify-center text-xs border border-[#00A19A] bg-[#00A19A] text-white rounded-lg px-3 py-2 mt-3'
                              onClick={() => handleReadMore(blog.blogId, blog.blogTitle, userId)}>
                              Read More
                              <AiOutlineDoubleRight size={10} />
                            </button>
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Blog pagination */}
              <div className="justify-center items-center mt-5">
                <div className="flex flex-row m-2 font-poppins common-pointer justify-center items-center">
                  <Img
                    className={`h-[13px] w-[15px] ${currentPageBlog > 1 ? 'common-pointer' : 'hidden'}`}
                    src="/images/img_arrowleftmp.svg"
                    alt="arrowleft"
                    onClick={() => handleArrowClick('left')}
                  />
                  {getPageButtonsRange().map((pageNumber) => (
                    pageNumber < totalPagesBlog ? (
                      <ButtonMp
                        key={pageNumber}
                        className={`shadow-lg flex h-[37px] w-[37px] common-pointer items-center justify-center ml-3 rounded-full text-center text-shadow-ts text-md tracking-[-0.30px]
                              ${currentPageBlog === pageNumber ? ' bg-cyan-700 text-white' : 'bg-white text-gray-700'}`}
                        size="txtPoppinsMedium20"
                        onClick={() => setCurrentPageBlog(pageNumber)}
                      >
                        {pageNumber}
                      </ButtonMp>
                    ) : null
                  ))}
                  {currentPageBlog < totalPagesBlog - 1 && (
                    <span className="text-gray-500 mx-2 font-bold">. . .</span>
                  )}
                  <ButtonMp
                    className={`shadow-lg flex h-[37px] w-[37px] common-pointer items-center justify-center rounded-full text-center text-shadow-ts text-md tracking-[-0.30px]
                              ${currentPageBlog === totalPagesBlog ? ' bg-cyan-700 text-white ml-3' : 'bg-white text-gray-700'}
                              ${currentPageBlog === totalPagesBlog - 1 ? ' ml-3' : ''}`}
                    size="txtPoppinsMedium20"
                  >
                    {totalPagesBlog}
                  </ButtonMp>
                  <Img
                    className={`h-[13px] w-[15px] ml-3 ${currentPageBlog < totalPagesBlog ? 'common-pointer' : 'hidden'}`}
                    src="/images/img_arrowright_gray_700_01.svg"
                    alt="arrowright_One"
                    onClick={() => handleArrowClick('right')}
                  />
                </div>
              </div>
            </>
          ) : null}
        </div>


        {/* photos display */}
        <div className='w-full mt-5 mb-5'>
          {isPhoto ? (
            <p className='font-bold text-gray-700 m-2'>Photos</p>
          ) : null}
          <div className='p-2 grid grid-cols-2 lg:grid-cols-4 gap-6 pb-3'>
            {contents.filter(data => data.category === 'photos').map(photo => (
              <div>
                <div className='border shadow-lg rounded-lg hover:scale-105 duration-300'>
                  <img
                    src={photo.image}
                    alt={photo.name}
                    className='w-full h-[200px] object-cover rounded-t-lg'
                  />
                  <div className='flex items-center gap-2 px-2 py-4'>
                    <IoPricetagSharp />
                    <p className='font-bold'>{photo.name}</p>

                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* videos display */}
        <div>
          {isVideo ? (
            <p className='font-bold text-gray-700 m-2'>Videos</p>
          ) : null}
          <div className='p-2 grid grid-cols-2 lg:grid-cols-4 gap-6 pb-3'>
            {contents.filter(data => data.category === 'videos').map(filteredFood => (
              <div>
                <div className='border shadow-lg rounded-lg hover:scale-105 duration-300'>
                  <img
                    src={filteredFood.image}
                    alt={filteredFood.name}
                    className='w-full h-[200px] object-cover rounded-t-lg'
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* livestream display */}
        <div>
          {isLivestream ? (
            <p className='font-bold text-gray-700 m-2'>Livestreams</p>
          ) : null}
          <div className='p-2 grid grid-cols-2 lg:grid-cols-3 gap-6 pb-3'>
            {contents.filter(data => data.category === 'livestreams').map(filteredFood => (
              <div>
                <div className='border shadow-lg rounded-lg hover:scale-105 duration-300'>
                  <img
                    src={filteredFood.image}
                    alt={filteredFood.name}
                    className='w-full h-[200px] object-cover rounded-t-lg'
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>

  )
}

export default AppBlank;