import React, { useState, useRef } from 'react'
import { MdOutlineDone } from 'react-icons/md';
import './cke.css';
import { useNavigate } from '../../../../node_modules/react-router-dom/index';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import { useLocation } from 'react-router-dom';
import LoadingSpinner from 'components/LoadingSpinner/index';
import { useEffect } from 'react';
import axios from "axios";

import { registerLicense } from '@syncfusion/ej2-base';
import { HtmlEditor, Link, Image, Inject, RichTextEditorComponent, Toolbar } from '@syncfusion/ej2-react-richtexteditor';

const CkEditor = () => {
	registerLicense('Ngo9BigBOggjHTQxAR8/V1NGaF5cXmdCf1FpRmJGdld5fUVHYVZUTXxaS00DNHVRdkdgWXhednRRRWZeV0x/W0Y=');


	const [isLoading, setIsLoading] = useState(false);
	const location = useLocation();
	const { generatedBlogData } = location.state || {};
	const [editorData, setEditorData] = useState('');
	// const ckeditorRef = useRef();
	const richtextEditorRef = useRef();
	//navigate button
	const navigate = useNavigate();

	//button preview
	function handleNavigate1() {
		const editorText = richtextEditorRef.current.value;
		setEditorData(editorText);
		navigate("/blog-preview", { state: { generatedBlogData: editorText } })

	}

	const resetEditorContent = () => {
		setEditorData('');
	};

	//for dropdown list
	const [isVisible, setIsVisible] = useState("");

	//select
	const [selectedOption, setSelectedOption] = useState(null);

	const handleOptionSelect = (option) => {
		setSelectedOption(option);
	};

	const changeHandler = e => {
		const getshow = e.target.value;
		setIsVisible(getshow);
	}

	useEffect(() => {
		// Simulate loading delay with setTimeout (replace with your actual data fetching logic)
		const loadingDelay = setTimeout(() => {
			setIsLoading(false); // Set isLoading to false after the data is fetched (or simulated delay)
		}, 2000); // Adjust the delay as needed

		return () => clearTimeout(loadingDelay); // Clean up the timeout on component unmount
	}, []);

	useEffect(() => {
		setEditorData(generatedBlogData || editorData || ''); // Set the editorData state from the received content
	}, [generatedBlogData, editorData]);


	return (
		<div className=' flex flex-col font-montserrat mx-auto w-full h-auto'>
			<HeaderOTAAdmin />
			{/* <HeaderOTAMobile /> */}
			<div className='w-full p-4'>

				<div class="max-w-xl mx-auto my-4 ">
					<div class="flex pb-3">
						<div class="flex-1">
						</div>

						<div class="flex-1 items-center">
							<div class="w-10 h-10 bg-[#38b000] items-center border-2 border-grey-light mx-auto rounded-full flex">
								<MdOutlineDone size={20} className='text-white ml-2' />
							</div>
						</div>


						<div class="w-3/4 align-center items-center align-middle content-center flex">
							<div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
								<div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[100%]"></div>
							</div>
						</div>


						<div class="flex-1">
							<div class="w-10 h-10 bg-[#38b000] border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center">
								<MdOutlineDone size={20} className='text-white ml-2' />
							</div>
						</div>

						<div class="w-3/4 align-center items-center align-middle content-center flex">
							<div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
								<div class="bg-blue-600 rounded leading-none py-1 text-center dark:bg-blue-500 w-[100%]"></div>
							</div>
						</div>

						<div class="flex-1">
							<button class="w-10 h-10 bg-[#38b000] border-2 border-grey-light mx-auto rounded-full text-lg text-white flex items-center ">
								<MdOutlineDone size={20} className='text-white ml-2' />
							</button>
						</div>

						<div class="flex-1">
						</div>
					</div>

					<div class="flex text-sm content-center text-center">
						<div class="w-3/4 text-[#38b000]">
							Step 1: Blog Ideas + Titles
						</div>

						<div class="w-3/4 text-[#38b000]">
							Step 2: Blog Outline
						</div>

						<div class="w-3/4 text-[#38b000]">
							Step 3: Review and Generate
						</div>
					</div>
				</div>

				<div className='w-full flex flex-col justify-center items-center mt-4'>
					<div className='border border-gray-200 rounded-sm shadow p-4 h-[fit] sm:max-w-3xl'>

						<div className='mt-2 m-2 space-y-2'>
							{generatedBlogData ? (
								<RichTextEditorComponent
									ref={richtextEditorRef}
									value={editorData || generatedBlogData}>

									<Inject services={[Toolbar, Image, Link, HtmlEditor]} />
								 </RichTextEditorComponent>
							) : (
								<div className="flex justify-center"> {/* Center the spinner using flex */}
									<LoadingSpinner />
								</div>
							)}

						</div>

						<div className='m-5 flex justify-end gap-2'>
							{/*        */}
							<button className='bg-[#00A19A] text-white font-medium px-5 py-2 rounded-lg text-[13px]'
								onClick={handleNavigate1}
							>Preview</button>
						</div>


					</div>
				</div>



			</div>
		</div>

	)
}

export default CkEditor;