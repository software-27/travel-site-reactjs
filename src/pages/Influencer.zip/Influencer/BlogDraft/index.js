
import HeaderOTA from 'components/Header/HeaderOTA/index';
import React, { useState } from 'react'
import { MdOutlineDone } from 'react-icons/md';
// import './cke.css';
import { useNavigate } from '../../../../node_modules/react-router-dom/index';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import HeaderOTAAdmin from 'components/Header/HeaderOTAAdmin/index';
import { useLocation } from 'react-router-dom';
import LoadingSpinner from 'components/LoadingSpinner/index';
import { useEffect } from 'react';
import GlobalConstant from "constant/global";

const BlogDraft = () => {
	const [isLoading, setIsLoading] = useState(false);
	const location = useLocation();
	const { generatedBlogData } = location.state || {};



	//navigate button
	const navigate = useNavigate();

	function handleNavigate1() {
		// const postData = {
		// 	"images": imageUrl
		// };
		// handleSubmit(postData);
		// console.log('post photo: ', postData)
		navigate("/ckeditor")

	}
	//for dropdown list
	const [isVisible, setIsVisible] = useState("");

	//select
	const [selectedOption, setSelectedOption] = useState(null);

	const handleOptionSelect = (option) => {
		setSelectedOption(option);
	};

	const changeHandler = e => {
		const getshow = e.target.value;
		setIsVisible(getshow);
	}

	useEffect(() => {
		// Simulate loading delay with setTimeout (replace with your actual data fetching logic)
		const loadingDelay = setTimeout(() => {
			setIsLoading(false); // Set isLoading to false after the data is fetched (or simulated delay)
		}, 2000); // Adjust the delay as needed

		return () => clearTimeout(loadingDelay); // Clean up the timeout on component unmount
	}, []);

	const API_URL = "http://localhost:8080/api/creatorpage";
	const UPLOAD_ENDPOINT = "uploadImage"

	// function uploadAdapter(loader) {
	// 	return {
	// 	  upload: () => {
	// 		return new Promise((resolve) => {
	// 		  loader.file.then((file) => {
	// 			const reader = new FileReader();
	// 			reader.onload = () => {
	// 			  const url = reader.result;
	// 			  resolve({ default: url });
	// 			};
	// 			reader.readAsDataURL(file);
	// 		  });
	// 		});
	// 	  },
	// 	};
	//   }


	function uploadAdapter(loader) {
		return {
			upload: () => {
				return new Promise((resolve, reject) => {
					const body = new FormData();
					loader.file.then((file) => {
						body.append("images", file);
						let check = GlobalConstant.BASE_API + `/api/creatorpage/uploadImage`;
						console.log("check: ",check, "test: ", GlobalConstant.TEST);
						fetch(GlobalConstant.BASE_API + `/api/creatorpage/uploadImage`, {
						// fetch(`${API_URL}/${UPLOAD_ENDPOINT}`, {
							method: "POST",
							body: body
						}).then((res => res.json()))
							.then((res) => {
								 // The response should contain the URL of the uploaded image
								 if (res && res.url) {
									resolve({ default: `${API_URL}/${res.url}`});
								//   } else {
								// 	reject(new Error("Invalid response format"));
								//   }
							}
						})
							.catch((err) => {
								reject(err);
							})
					})
				})
			}
		}
	}

	function uploadPlugin(editor) {
		editor.plugins.get("FileRepository").createUploadAdapter = (loader) => {
			return uploadAdapter(loader);
		}
	}


  return (
    <div className=' flex flex-col font-montserrat mx-auto w-full h-auto '>
    <HeaderOTAAdmin />
    {/* <HeaderOTAMobile /> */}
    <div className='mx-48'>
    <div className='mt-8 '>
	<CKEditor
                    editor={ ClassicEditor }
                    data="<p>Hello from CKEditor 5!</p>"
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                />
				<div className='m-2 flex justify-end gap-2'>
					<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
						onClick={handleNavigate1}
					>Save as Draft</button>
					<button className='bg-[#00A19A] text-white font-medium px-5 py-1 rounded-lg text-[10px]'
						onClick={handleNavigate1}
					>Publish</button>
				</div>
		</div>
    </div>
	</div>
    

)
}

export default BlogDraft;